using System;
using System.Windows.Forms;
using oop_project2_Elitegrp.Forms;

namespace oop_project2_Elitegrp
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.Run(new Main_Form());
        }
    }
}
