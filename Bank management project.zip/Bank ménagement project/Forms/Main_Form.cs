using System;
using System.Drawing;
using System.Windows.Forms;
using oop_project2_Elitegrp.Classes;

namespace oop_project2_Elitegrp.Forms
{
    public class Main_Form : Form
    {
    
        private static readonly Color C_Bg         = Color.FromArgb(245, 247, 250);
        private static readonly Color C_Card        = Color.FromArgb(255, 255, 255);
        private static readonly Color C_Primary     = Color.FromArgb(79, 110, 171);
        private static readonly Color C_Primary_Dk  = Color.FromArgb(55,  85, 145);
        private static readonly Color C_Section     = Color.FromArgb(230, 236, 250);
        private static readonly Color C_Section_Txt = Color.FromArgb(55,  85, 145);
        private static readonly Color C_Danger      = Color.FromArgb(195, 75,  75);
        private static readonly Color C_Text        = Color.FromArgb(40,  44,  52);
        private static readonly Color C_Sub         = Color.FromArgb(120, 130, 150);
        private static readonly Font  F_Title       = new Font("Segoe UI", 17, FontStyle.Bold);
        private static readonly Font  F_Section     = new Font("Segoe UI", 9,  FontStyle.Bold);
        private static readonly Font  F_Btn         = new Font("Segoe UI", 10, FontStyle.Bold);
        private static readonly Font  F_Sub         = new Font("Segoe UI", 8,  FontStyle.Italic);

        private Label  Lbl_Title, Lbl_Customer_Section, Lbl_Staff_Section, Lbl_Team;
        private Button Btn_Add_Customer, Btn_Show_Customer, Btn_Add_Staff, Btn_Show_Staff, Btn_Exit;
        private Panel  Pnl_Card;

        public Main_Form()
        {
            Init_Components();
            Sample_Data.Seed_If_Empty();
        }

        private void Init_Components()
        {
            this.Text            = "My Bank Management";
            this.StartPosition   = FormStartPosition.CenterScreen;
            this.BackColor       = C_Bg;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox     = false;
            this.ClientSize      = new Size(400, 485);

            
            Panel Pnl_Header = new Panel();
            Pnl_Header.Size      = new Size(400, 70);
            Pnl_Header.Location  = new Point(0, 0);
            Pnl_Header.BackColor = C_Primary;

            Lbl_Title = new Label();
            Lbl_Title.Text      = "🏦  My Bank Management";
            Lbl_Title.Font      = F_Title;
            Lbl_Title.ForeColor = Color.White;
            Lbl_Title.Size      = new Size(380, 60);
            Lbl_Title.Location  = new Point(10, 5);
            Lbl_Title.TextAlign = ContentAlignment.MiddleCenter;
            Pnl_Header.Controls.Add(Lbl_Title);

            
            Pnl_Card = new Panel();
            Pnl_Card.Size      = new Size(360, 340);
            Pnl_Card.Location  = new Point(20, 85);
            Pnl_Card.BackColor = C_Card;
            
            Pnl_Card.Paint += (s, e) => {
                ControlPaint.DrawBorder(e.Graphics, Pnl_Card.ClientRectangle,
                    Color.FromArgb(210, 215, 230), ButtonBorderStyle.Solid);
            };

            
            Lbl_Customer_Section = Make_Section_Label("  👤  Customer Control", 0, 0);
            Btn_Add_Customer     = Make_Main_Button("＋  Add Customer",   0, 35);
            Btn_Show_Customer    = Make_Main_Button("🔍  Show Customers", 0, 85);
            Btn_Add_Customer.Click  += (s, e) => { new Add_Customer_Form().ShowDialog(); };
            Btn_Show_Customer.Click += (s, e) => { new Show_Customer_Form().ShowDialog(); };

    
            Lbl_Staff_Section = Make_Section_Label("  🧑‍💼  Staff Control", 0, 145);
            Btn_Add_Staff     = Make_Main_Button("＋  Add Staff",   0, 180);
            Btn_Show_Staff    = Make_Main_Button("🔍  Show Staff",  0, 230);
            Btn_Add_Staff.Click  += (s, e) => { new Add_Staff_Form().ShowDialog(); };
            Btn_Show_Staff.Click += (s, e) => { new Show_Staff_Form().ShowDialog(); };

            
            Lbl_Team = new Label();
            Lbl_Team.Text      = "Programmed by EliteGrp";
            Lbl_Team.Font      = F_Sub;
            Lbl_Team.ForeColor = C_Sub;
            Lbl_Team.Size      = new Size(360, 20);
            Lbl_Team.Location  = new Point(0, 295);
            Lbl_Team.TextAlign = ContentAlignment.MiddleCenter;

            Pnl_Card.Controls.AddRange(new Control[] {
                Lbl_Customer_Section, Btn_Add_Customer, Btn_Show_Customer,
                Lbl_Staff_Section, Btn_Add_Staff, Btn_Show_Staff, Lbl_Team
            });

            
            Btn_Exit = new Button();
            Btn_Exit.Text      = "Exit";
            Btn_Exit.Size      = new Size(360, 36);
            Btn_Exit.Location  = new Point(20, 435);
            Btn_Exit.BackColor = C_Danger;
            Btn_Exit.ForeColor = Color.White;
            Btn_Exit.FlatStyle = FlatStyle.Flat;
            Btn_Exit.FlatAppearance.BorderSize = 0;
            Btn_Exit.Font      = F_Btn;
            Btn_Exit.Click    += (s, e) => Application.Exit();

            this.Controls.AddRange(new Control[] { Pnl_Header, Pnl_Card, Btn_Exit });
        }

        private Label Make_Section_Label(string Text, int X, int Y)
        {
            Label L = new Label();
            L.Text      = Text;
            L.Font      = F_Section;
            L.ForeColor = C_Section_Txt;
            L.BackColor = C_Section;
            L.Size      = new Size(360, 28);
            L.Location  = new Point(X, Y);
            L.TextAlign = ContentAlignment.MiddleLeft;
            return L;
        }

        private Button Make_Main_Button(string Text, int X, int Y)
        {
            Button B = new Button();
            B.Text      = Text;
            B.Size      = new Size(320, 42);
            B.Location  = new Point(X + 20, Y);
            B.BackColor = C_Primary;
            B.ForeColor = Color.White;
            B.FlatStyle = FlatStyle.Flat;
            B.FlatAppearance.BorderSize = 0;
            B.Font      = F_Btn;
            B.Cursor    = Cursors.Hand;
            B.MouseEnter += (s, e) => ((Button)s).BackColor = C_Primary_Dk;
            B.MouseLeave += (s, e) => ((Button)s).BackColor = C_Primary;
            return B;
        }
    }
}
