using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using oop_project2_Elitegrp.Classes;

namespace oop_project2_Elitegrp.Forms
{
    public class Edit_Customer_Form : Form
    {
        private static readonly Color C_Bg      = Color.FromArgb(245, 247, 250);
        private static readonly Color C_Primary = Color.FromArgb(79,  110, 171);
        private static readonly Color C_Accent  = Color.FromArgb(230, 236, 250);
        private static readonly Color C_Green   = Color.FromArgb(67,  160, 100);
        private static readonly Color C_Green_Dk= Color.FromArgb(45,  130, 75);
        private static readonly Color C_Danger  = Color.FromArgb(195, 75,  75);
        private static readonly Color C_Text    = Color.FromArgb(40,  44,  52);
        private static readonly Color C_Key     = Color.FromArgb(80,  95,  130);
        private static readonly Font  F_Title   = new Font("Segoe UI", 15, FontStyle.Bold);
        private static readonly Font  F_Label   = new Font("Segoe UI", 9,  FontStyle.Bold);
        private static readonly Font  F_Input   = new Font("Segoe UI", 9);
        private static readonly Font  F_Btn     = new Font("Segoe UI", 10, FontStyle.Bold);

        private Label    Lbl_Title;
        private Label    Lbl_Name, Lbl_Last_Name, Lbl_Email, Lbl_Contact, Lbl_Plan, Lbl_Address;
        private TextBox  Txt_Name, Txt_Last_Name, Txt_Email, Txt_Contact, Txt_Address;
        private ComboBox Cmb_Plan;
        private PictureBox Pic_Photo;
        private Button   Btn_Change_Image, Btn_Modify, Btn_Cancel;
        private Label    Lbl_Account_Key, Lbl_Account_Val, Lbl_ID_Key, Lbl_ID_Val;
        private Label    Lbl_Balance_Key, Lbl_Balance_Val, Lbl_Savings_Key, Lbl_Savings_Val;

        private Customer Current_Customer;
        private string   Photo_Path;

        public Edit_Customer_Form(Customer Customer_Object)
        {
            Current_Customer = Customer_Object;
            Photo_Path       = Customer_Object.Get_Photo_Path();
            Init_Components();
            Load_Customer_Data();
        }

        private void Init_Components()
        {
            this.Text            = "Edit Customer";
            this.Size            = new Size(530, 480);
            this.StartPosition   = FormStartPosition.CenterScreen;
            this.BackColor       = C_Bg;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox     = false;

            Panel Pnl_Header = new Panel();
            Pnl_Header.Size      = new Size(530, 55);
            Pnl_Header.Location  = new Point(0, 0);
            Pnl_Header.BackColor = C_Primary;

            Lbl_Title = new Label();
            Lbl_Title.Text      = "Edit Customer";
            Lbl_Title.Font      = F_Title;
            Lbl_Title.ForeColor = Color.White;
            Lbl_Title.Size      = new Size(510, 50);
            Lbl_Title.Location  = new Point(10, 3);
            Lbl_Title.TextAlign = ContentAlignment.MiddleCenter;
            Pnl_Header.Controls.Add(Lbl_Title);

            Pic_Photo = new PictureBox();
            Pic_Photo.Size        = new Size(110, 110);
            Pic_Photo.Location    = new Point(390, 65);
            Pic_Photo.BorderStyle = BorderStyle.FixedSingle;
            Pic_Photo.SizeMode    = PictureBoxSizeMode.Zoom;
            Pic_Photo.BackColor   = Color.FromArgb(220, 225, 235);

            Btn_Change_Image = new Button();
            Btn_Change_Image.Text      = "📷 Change";
            Btn_Change_Image.Size      = new Size(110, 28);
            Btn_Change_Image.Location  = new Point(390, 180);
            Btn_Change_Image.BackColor = C_Accent;
            Btn_Change_Image.ForeColor = C_Primary;
            Btn_Change_Image.FlatStyle = FlatStyle.Flat;
            Btn_Change_Image.FlatAppearance.BorderColor = C_Primary;
            Btn_Change_Image.Font      = new Font("Segoe UI", 8, FontStyle.Bold);
            Btn_Change_Image.Click    += Btn_Change_Image_Click;

            int Lx = 25, Ix = 135, Ry = 36, Sy = 70;

            Lbl_Name      = Make_Label("Name:",      Lx, Sy);
            Txt_Name      = Make_Input(Ix, Sy, 220);
            Lbl_Last_Name = Make_Label("Last Name:", Lx, Sy + Ry);
            Txt_Last_Name = Make_Input(Ix, Sy + Ry, 220);
            Lbl_Email     = Make_Label("Email:",     Lx, Sy + Ry * 2);
            Txt_Email     = Make_Input(Ix, Sy + Ry * 2, 220);
            Lbl_Contact   = Make_Label("Contact:",   Lx, Sy + Ry * 3);
            Txt_Contact   = Make_Input(Ix, Sy + Ry * 3, 220);

            Lbl_Plan = Make_Label("Plan:", Lx, Sy + Ry * 4);
            Cmb_Plan = new ComboBox();
            Cmb_Plan.Size          = new Size(160, 26);
            Cmb_Plan.Location      = new Point(Ix, Sy + Ry * 4);
            Cmb_Plan.DropDownStyle = ComboBoxStyle.DropDownList;
            Cmb_Plan.Font          = F_Input;
            Cmb_Plan.Items.AddRange(new string[] { "Basic", "Silver Saving", "Gold Saving" });

            Lbl_Address = Make_Label("Address:", Lx, Sy + Ry * 5);
            Txt_Address = Make_Input(Ix, Sy + Ry * 5, 340);

            
            Panel Pnl_Info = new Panel();
            Pnl_Info.Size      = new Size(480, 64);
            Pnl_Info.Location  = new Point(25, 295);
            Pnl_Info.BackColor = C_Accent;

            Lbl_Account_Key = Make_Info_Key("Account:", 8, 8);
            Lbl_Account_Val = Make_Info_Val(70, 8, 155);
            Lbl_ID_Key      = Make_Info_Key("ID:", 238, 8);
            Lbl_ID_Val      = Make_Info_Val(258, 8, 100);
            Lbl_Balance_Key = Make_Info_Key("Balance:", 8, 36);
            Lbl_Balance_Val = Make_Info_Val(70, 36, 100);
            Lbl_Savings_Key = Make_Info_Key("Savings:", 238, 36);
            Lbl_Savings_Val = Make_Info_Val(300, 36, 100);

            Pnl_Info.Controls.AddRange(new Control[] {
                Lbl_Account_Key, Lbl_Account_Val,
                Lbl_ID_Key, Lbl_ID_Val,
                Lbl_Balance_Key, Lbl_Balance_Val,
                Lbl_Savings_Key, Lbl_Savings_Val
            });

            Btn_Modify = Make_Action_Button("✔  Modify", 25, 382, C_Green, C_Green_Dk);
            Btn_Modify.Click += Btn_Modify_Click;

            Btn_Cancel = Make_Action_Button("✖  Cancel", 390, 382, C_Danger, Color.FromArgb(165, 50, 50));
            Btn_Cancel.Click += (s, e) => this.Close();

            this.Controls.AddRange(new Control[] {
                Pnl_Header, Pic_Photo, Btn_Change_Image,
                Lbl_Name, Txt_Name, Lbl_Last_Name, Txt_Last_Name,
                Lbl_Email, Txt_Email, Lbl_Contact, Txt_Contact,
                Lbl_Plan, Cmb_Plan, Lbl_Address, Txt_Address,
                Pnl_Info, Btn_Modify, Btn_Cancel
            });
        }

        private Label Make_Label(string Text, int X, int Y)
        {
            Label L = new Label();
            L.Text      = Text;
            L.Size      = new Size(108, 22);
            L.Location  = new Point(X, Y + 4);
            L.Font      = F_Label;
            L.ForeColor = C_Text;
            return L;
        }

        private Label Make_Info_Key(string Text, int X, int Y)
        {
            Label L = new Label();
            L.Text      = Text;
            L.Size      = new Size(62, 18);
            L.Location  = new Point(X, Y);
            L.Font      = new Font("Segoe UI", 8, FontStyle.Bold);
            L.ForeColor = C_Key;
            return L;
        }

        private Label Make_Info_Val(int X, int Y, int Width)
        {
            Label L = new Label();
            L.Size      = new Size(Width, 18);
            L.Location  = new Point(X, Y);
            L.Font      = new Font("Segoe UI", 8, FontStyle.Bold);
            L.ForeColor = C_Primary;
            return L;
        }

        private TextBox Make_Input(int X, int Y, int Width)
        {
            TextBox T = new TextBox();
            T.Size        = new Size(Width, 24);
            T.Location    = new Point(X, Y);
            T.Font        = F_Input;
            T.BorderStyle = BorderStyle.FixedSingle;
            return T;
        }

        private Button Make_Action_Button(string Text, int X, int Y, Color Bg, Color Hover)
        {
            Button B = new Button();
            B.Text      = Text;
            B.Size      = new Size(110, 36);
            B.Location  = new Point(X, Y);
            B.BackColor = Bg;
            B.ForeColor = Color.White;
            B.FlatStyle = FlatStyle.Flat;
            B.FlatAppearance.BorderSize = 0;
            B.Font      = F_Btn;
            B.Cursor    = Cursors.Hand;
            B.MouseEnter += (s, e) => ((Button)s).BackColor = Hover;
            B.MouseLeave += (s, e) => ((Button)s).BackColor = Bg;
            return B;
        }

        private void Load_Customer_Data()
        {
            Txt_Name.Text      = Current_Customer.Get_Name();
            Txt_Last_Name.Text = Current_Customer.Get_Last_Name();
            Txt_Email.Text     = Current_Customer.Get_Email();
            Txt_Contact.Text   = Current_Customer.Get_Phone_Number();
            Txt_Address.Text   = Current_Customer.Get_Address();
            int Plan_Index = Cmb_Plan.Items.IndexOf(Current_Customer.Get_Plan());
            Cmb_Plan.SelectedIndex = Plan_Index >= 0 ? Plan_Index : 0;
            Lbl_Account_Val.Text = Current_Customer.Get_Account_Number();
            Lbl_ID_Val.Text      = Current_Customer.Get_Customer_ID();
            Lbl_Balance_Val.Text = Current_Customer.Get_Balance().ToString("F2") + " PLN";
            Lbl_Savings_Val.Text = Current_Customer.Get_Savings().ToString("F2") + " PLN";
            try
            {
                string Full_Path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, Current_Customer.Get_Photo_Path());
                if (!string.IsNullOrEmpty(Current_Customer.Get_Photo_Path()) && File.Exists(Full_Path))
                    Pic_Photo.Image = Image.FromFile(Full_Path);
            }
            catch { }
        }

        private void Btn_Change_Image_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog Dlg = new OpenFileDialog();
                Dlg.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";
                if (Dlg.ShowDialog() == DialogResult.OK)
                {
                    string Dest_Folder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Photos");
                    Directory.CreateDirectory(Dest_Folder);
                    string Dest_File = Path.Combine(Dest_Folder, Path.GetFileName(Dlg.FileName));
                    File.Copy(Dlg.FileName, Dest_File, true);
                    Photo_Path = "Photos\\" + Path.GetFileName(Dlg.FileName);
                    Pic_Photo.Image = Image.FromFile(Dest_File);
                }
            }
            catch (Exception ex) { MessageBox.Show("Error loading photo: " + ex.Message); }
        }

        private void Btn_Modify_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(Txt_Name.Text) || string.IsNullOrWhiteSpace(Txt_Last_Name.Text))
                {
                    MessageBox.Show("Name and Last Name are required!", "Validation Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                Current_Customer.Set_Name(Txt_Name.Text.Trim());
                Current_Customer.Set_Last_Name(Txt_Last_Name.Text.Trim());
                Current_Customer.Set_Email(Txt_Email.Text.Trim());
                Current_Customer.Set_Phone_Number(Txt_Contact.Text.Trim());
                Current_Customer.Set_Address(Txt_Address.Text.Trim());
                Current_Customer.Set_Plan(Cmb_Plan.SelectedItem.ToString());
                Current_Customer.Set_Photo_Path(Photo_Path);
                List<Customer> Customer_List = File_Manager.Load_Customers();
                int Index = Customer_List.FindIndex(c => c.Get_Customer_ID() == Current_Customer.Get_Customer_ID());
                if (Index >= 0) Customer_List[Index] = Current_Customer;
                File_Manager.Update_All_Customers(Customer_List);
                MessageBox.Show("Customer updated successfully!", "Success",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
