using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using oop_project2_Elitegrp.Classes;

namespace oop_project2_Elitegrp.Forms
{
    public class Show_Staff_Form : Form
    {
        private static readonly Color C_Bg        = Color.FromArgb(245, 247, 250);
        private static readonly Color C_Card      = Color.White;
        private static readonly Color C_Primary   = Color.FromArgb(79,  110, 171);
        private static readonly Color C_Accent    = Color.FromArgb(230, 236, 250);
        private static readonly Color C_Danger    = Color.FromArgb(195, 75,  75);
        private static readonly Color C_Orange    = Color.FromArgb(220, 130, 50);
        private static readonly Color C_Orange_Dk = Color.FromArgb(185, 100, 30);
        private static readonly Color C_Text      = Color.FromArgb(40,  44,  52);
        private static readonly Color C_Key       = Color.FromArgb(80,  95,  130);
        private static readonly Font  F_Title     = new Font("Segoe UI", 16, FontStyle.Bold);
        private static readonly Font  F_Counter   = new Font("Segoe UI", 12, FontStyle.Bold);
        private static readonly Font  F_Key       = new Font("Segoe UI", 9,  FontStyle.Bold);
        private static readonly Font  F_Val       = new Font("Segoe UI", 9);
        private static readonly Font  F_Btn       = new Font("Segoe UI", 10, FontStyle.Bold);
        private static readonly Font  F_Btn_Sm    = new Font("Segoe UI", 9,  FontStyle.Bold);

        private Label  Lbl_Title, Lbl_Counter;
        private Button Btn_Prev, Btn_Next;
        private Panel  Pnl_Card;

        private Label  Lbl_ID_Key,      Lbl_ID_Val;
        private Label  Lbl_Name_Key,    Lbl_Name_Val;
        private Label  Lbl_Last_Key,    Lbl_Last_Val;
        private Label  Lbl_Email_Key,   Lbl_Email_Val;
        private Label  Lbl_Phone_Key,   Lbl_Phone_Val;
        private Label  Lbl_Address_Key, Lbl_Address_Val;
        private Label  Lbl_Role_Key,    Lbl_Role_Val;
        private Label  Lbl_Hours_Key,   Lbl_Hours_Val;
        private Label  Lbl_Extra_Key,   Lbl_Extra_Val;
        private Label  Lbl_Salary_Key,  Lbl_Salary_Val;
        private Label  Lbl_Balance_Key, Lbl_Balance_Val;

        private PictureBox Pic_Photo;
        private Button     Btn_Staff_Managing, Btn_Delete, Btn_Exit;

        private List<Staff> Staff_List;
        private int Current_Index = 0;

   

        private const int FORM_W = 780;
        private const int CARD_X = 20;
        private const int CARD_W = 740;

        private const int La  = 10;
        private const int Va  = 128;
        private const int WVa = 160;
        private const int Lb  = 298;
        private const int Vb  = 418;
        private const int WVb = 120;
        private const int Px  = 558;
        private const int PW  = 120;
        private const int PH  = 120;
        private const int Ry  = 30;
        private const int Sy  = 32;

        public Show_Staff_Form()
        {
            Staff_List = File_Manager.Load_Staff();
            Init_Components();
            if (Staff_List.Count > 0) Display_Staff(0);
        }

        private void Init_Components()
        {
            this.Text            = "Show Staff";
            this.StartPosition   = FormStartPosition.CenterScreen;
            this.BackColor       = C_Bg;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox     = false;

        
            Panel Pnl_Header = new Panel();
            Pnl_Header.Size      = new Size(FORM_W, 55);
            Pnl_Header.Location  = new Point(0, 0);
            Pnl_Header.BackColor = C_Primary;

            Lbl_Title = new Label();
            Lbl_Title.Text      = "Show Staff";
            Lbl_Title.Font      = F_Title;
            Lbl_Title.ForeColor = Color.White;
            Lbl_Title.Size      = new Size(FORM_W - 20, 50);
            Lbl_Title.Location  = new Point(10, 3);
            Lbl_Title.TextAlign = ContentAlignment.MiddleCenter;
            Pnl_Header.Controls.Add(Lbl_Title);

        
            int Nav_Btn_W = 34;
            Btn_Prev = Make_Nav_Btn("<", 20, 65);
            Btn_Prev.Click += (s, e) => Navigate(-1);

            Lbl_Counter = new Label();
            Lbl_Counter.Size      = new Size(FORM_W - 20 - Nav_Btn_W * 2 - 20, 30);
            Lbl_Counter.Location  = new Point(20 + Nav_Btn_W + 4, 65);
            Lbl_Counter.TextAlign = ContentAlignment.MiddleCenter;
            Lbl_Counter.Font      = F_Counter;
            Lbl_Counter.ForeColor = C_Primary;

            Btn_Next = Make_Nav_Btn(">", FORM_W - 20 - Nav_Btn_W, 65);
            Btn_Next.Click += (s, e) => Navigate(1);

            
            Pnl_Card = new Panel();
            Pnl_Card.Location  = new Point(CARD_X, 103);
            Pnl_Card.BackColor = C_Card;
            Pnl_Card.Paint    += (s, e) => ControlPaint.DrawBorder(e.Graphics, Pnl_Card.ClientRectangle,
                                     Color.FromArgb(210, 215, 230), ButtonBorderStyle.Solid);

            Panel Pnl_Sec = new Panel();
            Pnl_Sec.Location  = new Point(0, 0);
            Pnl_Sec.BackColor = C_Accent;
            Label Lbl_Sec = new Label();
            Lbl_Sec.Text      = "  Staff Information";
            Lbl_Sec.Font      = new Font("Segoe UI", 9, FontStyle.Bold);
            Lbl_Sec.ForeColor = C_Key;
            Lbl_Sec.Dock      = DockStyle.Fill;
            Lbl_Sec.TextAlign = ContentAlignment.MiddleLeft;
            Pnl_Sec.Controls.Add(Lbl_Sec);

        
            Lbl_ID_Key   = Make_Key("Staff ID:", La, Sy);
            Lbl_ID_Val   = Make_Val(Va, Sy, WVa);
            Lbl_Role_Key = Make_Key("Role:",     Lb, Sy);
            Lbl_Role_Val = Make_Val(Vb, Sy, WVb);

    
            Lbl_Name_Key  = Make_Key("Name:",  La, Sy + Ry);
            Lbl_Name_Val  = Make_Val(Va, Sy + Ry, WVa);
            Lbl_Hours_Key = Make_Key("Hours:", Lb, Sy + Ry);
            Lbl_Hours_Val = Make_Val(Vb, Sy + Ry, WVb);


            Lbl_Last_Key  = Make_Key("Last Name:",   La, Sy + Ry * 2);
            Lbl_Last_Val  = Make_Val(Va, Sy + Ry * 2, WVa);
            Lbl_Extra_Key = Make_Key("Extra Hours:", Lb, Sy + Ry * 2);
            Lbl_Extra_Val = Make_Val(Vb, Sy + Ry * 2, WVb);

            
            Lbl_Email_Key  = Make_Key("Email:",      La, Sy + Ry * 3);
            Lbl_Email_Val  = Make_Val(Va, Sy + Ry * 3, WVa);
            Lbl_Salary_Key = Make_Key("Salary P/H:", Lb, Sy + Ry * 3);
            Lbl_Salary_Val = Make_Val(Vb, Sy + Ry * 3, WVb);

        
            Lbl_Phone_Key   = Make_Key("Phone:",   La, Sy + Ry * 4);
            Lbl_Phone_Val   = Make_Val(Va, Sy + Ry * 4, WVa);
            Lbl_Balance_Key = Make_Key("Balance:", Lb, Sy + Ry * 4);
            Lbl_Balance_Val = Make_Val(Vb, Sy + Ry * 4, WVb);

            
            Lbl_Address_Key = Make_Key("Address:", La, Sy + Ry * 5);
            Lbl_Address_Val = Make_Val(Va, Sy + Ry * 5, Px - Va - 10);

            int Rows_Bottom = Sy + Ry * 6;

    
            Pic_Photo = new PictureBox();
            Pic_Photo.Size        = new Size(PW, PH);
            Pic_Photo.Location    = new Point(Px, Sy);
            Pic_Photo.BorderStyle = BorderStyle.FixedSingle;
            Pic_Photo.SizeMode    = PictureBoxSizeMode.Zoom;
            Pic_Photo.BackColor   = Color.FromArgb(220, 225, 235);

            Btn_Staff_Managing = new Button();
            Btn_Staff_Managing.Text      = "⚙ Manage";
            Btn_Staff_Managing.Size      = new Size(PW, 36);
            Btn_Staff_Managing.Location  = new Point(Px, Sy + PH + 8);
            Btn_Staff_Managing.BackColor = C_Orange;
            Btn_Staff_Managing.ForeColor = Color.White;
            Btn_Staff_Managing.FlatStyle = FlatStyle.Flat;
            Btn_Staff_Managing.FlatAppearance.BorderSize = 0;
            Btn_Staff_Managing.Font      = F_Btn_Sm;
            Btn_Staff_Managing.Cursor    = Cursors.Hand;
            Btn_Staff_Managing.MouseEnter += (s, e) => ((Button)s).BackColor = C_Orange_Dk;
            Btn_Staff_Managing.MouseLeave += (s, e) => ((Button)s).BackColor = C_Orange;
            Btn_Staff_Managing.Click     += Btn_Staff_Managing_Click;

            Btn_Delete = new Button();
            Btn_Delete.Text      = "🗑 Delete";
            Btn_Delete.Size      = new Size(PW, 36);
            Btn_Delete.Location  = new Point(Px, Sy + PH + 8 + 42);
            Btn_Delete.BackColor = C_Danger;
            Btn_Delete.ForeColor = Color.White;
            Btn_Delete.FlatStyle = FlatStyle.Flat;
            Btn_Delete.FlatAppearance.BorderSize = 0;
            Btn_Delete.Font      = F_Btn_Sm;
            Btn_Delete.Cursor    = Cursors.Hand;
            Btn_Delete.Click    += Btn_Delete_Click;

            
            int Btn_Delete_Bottom = Sy + PH + 8 + 42 + 36 + 10;
            int Card_Height = Math.Max(Rows_Bottom + 12, Btn_Delete_Bottom);
            Pnl_Sec.Size  = new Size(CARD_W, 26);
            Pnl_Card.Size = new Size(CARD_W, Card_Height);

            Pnl_Card.Controls.AddRange(new Control[] {
                Pnl_Sec,
                Lbl_ID_Key,   Lbl_ID_Val,   Lbl_Role_Key,   Lbl_Role_Val,
                Lbl_Name_Key, Lbl_Name_Val, Lbl_Hours_Key,  Lbl_Hours_Val,
                Lbl_Last_Key, Lbl_Last_Val, Lbl_Extra_Key,  Lbl_Extra_Val,
                Lbl_Email_Key, Lbl_Email_Val, Lbl_Salary_Key, Lbl_Salary_Val,
                Lbl_Phone_Key, Lbl_Phone_Val, Lbl_Balance_Key, Lbl_Balance_Val,
                Lbl_Address_Key, Lbl_Address_Val,
                Pic_Photo, Btn_Staff_Managing, Btn_Delete
            });

            int Exit_Y = 103 + Card_Height + 10;

            Btn_Exit = new Button();
            Btn_Exit.Text      = "Exit";
            Btn_Exit.Size      = new Size(200, 36);
            Btn_Exit.BackColor = C_Danger;
            Btn_Exit.ForeColor = Color.White;
            Btn_Exit.FlatStyle = FlatStyle.Flat;
            Btn_Exit.FlatAppearance.BorderSize = 0;
            Btn_Exit.Font      = F_Btn;
            Btn_Exit.Click    += (s, e) => this.Close();
            Btn_Exit.Location  = new Point((FORM_W - 200) / 2, Exit_Y);

            this.ClientSize = new Size(FORM_W, Exit_Y + 36 + 14);

            this.Controls.AddRange(new Control[] {
                Pnl_Header, Btn_Prev, Lbl_Counter, Btn_Next, Pnl_Card, Btn_Exit
            });
        }

        private Button Make_Nav_Btn(string Text, int X, int Y)
        {
            Button B = new Button();
            B.Text      = Text;
            B.Size      = new Size(34, 30);
            B.Location  = new Point(X, Y);
            B.BackColor = Color.FromArgb(230, 236, 250);
            B.ForeColor = C_Primary;
            B.FlatStyle = FlatStyle.Flat;
            B.FlatAppearance.BorderColor = C_Primary;
            B.Font      = new Font("Segoe UI", 10, FontStyle.Bold);
            return B;
        }

        private Label Make_Key(string Text, int X, int Y)
        {
            Label L = new Label();
            L.Text      = Text;
            L.Size      = new Size(108, 22);
            L.Location  = new Point(X, Y + 3);
            L.Font      = F_Key;
            L.ForeColor = C_Key;
            return L;
        }

        private Label Make_Val(int X, int Y, int Width)
        {
            Label L = new Label();
            L.Size      = new Size(Width, 22);
            L.Location  = new Point(X, Y + 3);
            L.Font      = F_Val;
            L.ForeColor = C_Text;
            return L;
        }

        private void Display_Staff(int Index)
        {
            if (Staff_List.Count == 0) { Lbl_Counter.Text = "No staff"; return; }
            Staff S = Staff_List[Index];
            Lbl_Counter.Text     = (Index + 1) + "  /  " + Staff_List.Count;
            Lbl_ID_Val.Text      = S.Get_Staff_ID();
            Lbl_Name_Val.Text    = S.Get_Name();
            Lbl_Last_Val.Text    = S.Get_Last_Name();
            Lbl_Email_Val.Text   = S.Get_Email();
            Lbl_Phone_Val.Text   = S.Get_Phone_Number();
            Lbl_Address_Val.Text = S.Get_Address();
            Lbl_Role_Val.Text    = S.Get_Role();
            Lbl_Hours_Val.Text   = S.Get_Normal_Hours().ToString();
            Lbl_Extra_Val.Text   = S.Get_Extra_Hours().ToString();
            Lbl_Salary_Val.Text  = S.Get_Salary_Per_Hour().ToString("F0") + " PLN";
            Lbl_Balance_Val.Text = S.Get_Staff_Balance().ToString("F2") + " PLN";
            try
            {
                Pic_Photo.Image = null;
                string Full_Path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, S.Get_Photo_Path());
                if (!string.IsNullOrEmpty(S.Get_Photo_Path()) && File.Exists(Full_Path))
                    Pic_Photo.Image = Image.FromFile(Full_Path);
            }
            catch { Pic_Photo.Image = null; }
        }

        private void Navigate(int Direction)
        {
            if (Staff_List.Count == 0) return;
            Current_Index = (Current_Index + Direction + Staff_List.Count) % Staff_List.Count;
            Display_Staff(Current_Index);
        }

        private void Btn_Staff_Managing_Click(object sender, EventArgs e)
        {
            if (Staff_List.Count == 0) return;
            new Staff_Control_Form(Staff_List[Current_Index]).ShowDialog();
            Staff_List = File_Manager.Load_Staff();
            if (Current_Index >= Staff_List.Count) Current_Index = 0;
            if (Staff_List.Count > 0) Display_Staff(Current_Index);
        }

        private void Btn_Delete_Click(object sender, EventArgs e)
        {
            if (Staff_List.Count == 0) return;
            Staff S = Staff_List[Current_Index];
            string Name = S.Get_Name() + " " + S.Get_Last_Name();
            DialogResult Confirm = MessageBox.Show(
                "Are you sure you want to delete staff member:\n" + Name + "?",
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);
            if (Confirm != DialogResult.Yes) return;

            Staff_List.RemoveAt(Current_Index);
            File_Manager.Update_All_Staff(Staff_List);

            if (Current_Index >= Staff_List.Count) Current_Index = 0;
            if (Staff_List.Count > 0)
                Display_Staff(Current_Index);
            else
                Lbl_Counter.Text = "No staff";
        }
    }
}
