using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using oop_project2_Elitegrp.Classes;

namespace oop_project2_Elitegrp.Forms
{
    public class Add_Customer_Form : Form
    {
        private static readonly Color C_Bg       = Color.FromArgb(245, 247, 250);
        private static readonly Color C_Primary  = Color.FromArgb(79,  110, 171);
        private static readonly Color C_Primary_Dk = Color.FromArgb(55, 85, 145);
        private static readonly Color C_Green    = Color.FromArgb(67,  160, 100);
        private static readonly Color C_Green_Dk = Color.FromArgb(45,  130, 75);
        private static readonly Color C_Danger   = Color.FromArgb(195, 75,  75);
        private static readonly Color C_Danger_Dk= Color.FromArgb(165, 50,  50);
        private static readonly Color C_Text     = Color.FromArgb(40,  44,  52);
        private static readonly Color C_Badge    = Color.FromArgb(230, 236, 250);
        private static readonly Font  F_Title    = new Font("Segoe UI", 15, FontStyle.Bold);
        private static readonly Font  F_Label    = new Font("Segoe UI", 9,  FontStyle.Bold);
        private static readonly Font  F_Input    = new Font("Segoe UI", 9);
        private static readonly Font  F_Badge    = new Font("Segoe UI", 9,  FontStyle.Bold);
        private static readonly Font  F_Btn      = new Font("Segoe UI", 10, FontStyle.Bold);

        private Label    Lbl_Title;
        private Label    Lbl_Name, Lbl_Last_Name, Lbl_Contact, Lbl_Email, Lbl_Address, Lbl_Balance, Lbl_Plan;
        private TextBox  Txt_Name, Txt_Last_Name, Txt_Contact, Txt_Email, Txt_Address, Txt_Balance;
        private ComboBox Cmb_Plan;
        private PictureBox Pic_Photo;
        private Button   Btn_Browse, Btn_Save, Btn_Cancel;
        private Label    Lbl_Account_Label, Lbl_Account_Value, Lbl_ID_Label, Lbl_ID_Value;

        private string         Photo_Path = "";
        private List<Customer> Customer_List;
        private string         Generated_ID;
        private string         Generated_Account;

        public Add_Customer_Form()
        {
            Customer_List     = File_Manager.Load_Customers();
            Generated_ID      = ID_Generator.Generate_Customer_ID(Customer_List);
            Generated_Account = ID_Generator.Generate_Account_Number(Customer_List);
            Init_Components();
        }

        private void Init_Components()
        {
            // Form is tall enough: header(55) + fields(7*36=252) + gap + ids(40) + gap + buttons(36) + margin
            this.Text            = "Add Customer";
            this.Size            = new Size(530, 510);
            this.StartPosition   = FormStartPosition.CenterScreen;
            this.BackColor       = C_Bg;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox     = false;

            // ── Header ──────────────────────────────────────────────────
            Panel Pnl_Header = new Panel();
            Pnl_Header.Size      = new Size(530, 55);
            Pnl_Header.Location  = new Point(0, 0);
            Pnl_Header.BackColor = C_Primary;

            Lbl_Title = new Label();
            Lbl_Title.Text      = "Add Customer";
            Lbl_Title.Font      = F_Title;
            Lbl_Title.ForeColor = Color.White;
            Lbl_Title.Size      = new Size(510, 50);
            Lbl_Title.Location  = new Point(10, 3);
            Lbl_Title.TextAlign = ContentAlignment.MiddleCenter;
            Pnl_Header.Controls.Add(Lbl_Title);

            
            Pic_Photo = new PictureBox();
            Pic_Photo.Size        = new Size(100, 100);
            Pic_Photo.Location    = new Point(405, 65);   
            Pic_Photo.BorderStyle = BorderStyle.FixedSingle;
            Pic_Photo.SizeMode    = PictureBoxSizeMode.Zoom;
            Pic_Photo.BackColor   = Color.FromArgb(220, 225, 235);

            Btn_Browse = new Button();
            Btn_Browse.Text      = "📷 Browse";
            Btn_Browse.Size      = new Size(100, 26);
            Btn_Browse.Location  = new Point(405, 170);   
            Btn_Browse.BackColor = C_Badge;
            Btn_Browse.ForeColor = C_Primary;
            Btn_Browse.FlatStyle = FlatStyle.Flat;
            Btn_Browse.FlatAppearance.BorderColor = C_Primary;
            Btn_Browse.Font      = new Font("Segoe UI", 8, FontStyle.Bold);
            Btn_Browse.Click    += Btn_Browse_Click;

        
            int Lx = 20, Ix = 120, W = 265, Ry = 36, Sy = 68;

            Lbl_Name      = Make_Label("Name:",      Lx, Sy);
            Txt_Name      = Make_Input(Ix, Sy, W);

            Lbl_Last_Name = Make_Label("Last Name:", Lx, Sy + Ry);
            Txt_Last_Name = Make_Input(Ix, Sy + Ry, W);

            Lbl_Contact   = Make_Label("Contact:",   Lx, Sy + Ry * 2);
            Txt_Contact   = Make_Input(Ix, Sy + Ry * 2, W);

            Lbl_Email     = Make_Label("Email:",     Lx, Sy + Ry * 3);
            Txt_Email     = Make_Input(Ix, Sy + Ry * 3, W);

            Lbl_Address   = Make_Label("Address:",   Lx, Sy + Ry * 4);
            Txt_Address   = Make_Input(Ix, Sy + Ry * 4, 370);  

            Lbl_Balance   = Make_Label("Balance:",   Lx, Sy + Ry * 5);
            Txt_Balance   = Make_Input(Ix, Sy + Ry * 5, 130);

            Lbl_Plan = Make_Label("Plan:", Lx, Sy + Ry * 6);
            Cmb_Plan = new ComboBox();
            Cmb_Plan.Size          = new Size(160, 26);
            Cmb_Plan.Location      = new Point(Ix, Sy + Ry * 6 + 2);
            Cmb_Plan.DropDownStyle = ComboBoxStyle.DropDownList;
            Cmb_Plan.Font          = F_Input;
            Cmb_Plan.Items.AddRange(new string[] { "Basic", "Silver Saving", "Gold Saving" });
            Cmb_Plan.SelectedIndex = 0;

    
            int Badge_Y = Sy + Ry * 7 + 6;   

            Panel Pnl_Ids = new Panel();
            Pnl_Ids.Size      = new Size(490, 34);
            Pnl_Ids.Location  = new Point(20, Badge_Y);
            Pnl_Ids.BackColor = C_Badge;

            Lbl_Account_Label = new Label();
            Lbl_Account_Label.Text      = "Account:";
            Lbl_Account_Label.Size      = new Size(62, 18);
            Lbl_Account_Label.Location  = new Point(8, 8);
            Lbl_Account_Label.Font      = new Font("Segoe UI", 8, FontStyle.Bold);
            Lbl_Account_Label.ForeColor = Color.FromArgb(100, 115, 145);

            Lbl_Account_Value = new Label();
            Lbl_Account_Value.Text      = Generated_Account;
            Lbl_Account_Value.Size      = new Size(190, 18);
            Lbl_Account_Value.Location  = new Point(72, 8);
            Lbl_Account_Value.Font      = F_Badge;
            Lbl_Account_Value.ForeColor = C_Primary;

            Lbl_ID_Label = new Label();
            Lbl_ID_Label.Text      = "Customer ID:";
            Lbl_ID_Label.Size      = new Size(85, 18);
            Lbl_ID_Label.Location  = new Point(272, 8);
            Lbl_ID_Label.Font      = new Font("Segoe UI", 8, FontStyle.Bold);
            Lbl_ID_Label.ForeColor = Color.FromArgb(100, 115, 145);

            Lbl_ID_Value = new Label();
            Lbl_ID_Value.Text      = Generated_ID;
            Lbl_ID_Value.Size      = new Size(120, 18);
            Lbl_ID_Value.Location  = new Point(360, 8);
            Lbl_ID_Value.Font      = F_Badge;
            Lbl_ID_Value.ForeColor = C_Primary;

            Pnl_Ids.Controls.AddRange(new Control[] {
                Lbl_Account_Label, Lbl_Account_Value, Lbl_ID_Label, Lbl_ID_Value
            });

            int Btn_Y = Badge_Y + 34 + 16;

            Btn_Save   = Make_Action_Button("✔  Save",   20,  Btn_Y, C_Green,  C_Green_Dk);
            Btn_Cancel = Make_Action_Button("✖  Cancel", 390, Btn_Y, C_Danger, C_Danger_Dk);
            Btn_Save.Click   += Btn_Save_Click;
            Btn_Cancel.Click += (s, e) => this.Close();

            this.ClientSize = new Size(530, Btn_Y + 36 + 14);

            this.Controls.AddRange(new Control[] {
                Pnl_Header, Pic_Photo, Btn_Browse,
                Lbl_Name, Txt_Name, Lbl_Last_Name, Txt_Last_Name,
                Lbl_Contact, Txt_Contact, Lbl_Email, Txt_Email,
                Lbl_Address, Txt_Address, Lbl_Balance, Txt_Balance,
                Lbl_Plan, Cmb_Plan, Pnl_Ids,
                Btn_Save, Btn_Cancel
            });
        }

        private Label Make_Label(string Text, int X, int Y)
        {
            Label L = new Label();
            L.Text      = Text;
            L.Size      = new Size(98, 22);
            L.Location  = new Point(X, Y + 4);
            L.Font      = F_Label;
            L.ForeColor = C_Text;
            return L;
        }

        private TextBox Make_Input(int X, int Y, int Width)
        {
            TextBox T = new TextBox();
            T.Size        = new Size(Width, 24);
            T.Location    = new Point(X, Y + 2);
            T.Font        = F_Input;
            T.BorderStyle = BorderStyle.FixedSingle;
            return T;
        }

        private Button Make_Action_Button(string Text, int X, int Y, Color Bg, Color Hover)
        {
            Button B = new Button();
            B.Text      = Text;
            B.Size      = new Size(115, 36);
            B.Location  = new Point(X, Y);
            B.BackColor = Bg;
            B.ForeColor = Color.White;
            B.FlatStyle = FlatStyle.Flat;
            B.FlatAppearance.BorderSize = 0;
            B.Font      = F_Btn;
            B.Cursor    = Cursors.Hand;
            B.MouseEnter += (s, e) => ((Button)s).BackColor = Hover;
            B.MouseLeave += (s, e) => ((Button)s).BackColor = Bg;
            return B;
        }

        private void Btn_Browse_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog Dlg = new OpenFileDialog();
                Dlg.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";
                if (Dlg.ShowDialog() == DialogResult.OK)
                {
                    string Dest_Folder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Photos");
                    Directory.CreateDirectory(Dest_Folder);
                    string Dest_File = Path.Combine(Dest_Folder, Path.GetFileName(Dlg.FileName));
                    File.Copy(Dlg.FileName, Dest_File, true);
                    Photo_Path = "Photos\\" + Path.GetFileName(Dlg.FileName);
                    Pic_Photo.Image = Image.FromFile(Dest_File);
                }
            }
            catch (Exception ex) { MessageBox.Show("Error loading photo: " + ex.Message); }
        }

        private void Btn_Save_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(Txt_Name.Text) || string.IsNullOrWhiteSpace(Txt_Last_Name.Text))
                {
                    MessageBox.Show("Name and Last Name are required!", "Validation Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                double Balance_Value;
                if (!double.TryParse(Txt_Balance.Text, out Balance_Value) || Balance_Value < 0)
                {
                    MessageBox.Show("Balance must be a valid positive number!", "Validation Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                Customer New_Customer = new Customer();
                New_Customer.Set_Customer_ID(Generated_ID);
                New_Customer.Set_Account_Number(Generated_Account);
                New_Customer.Set_Name(Txt_Name.Text.Trim());
                New_Customer.Set_Last_Name(Txt_Last_Name.Text.Trim());
                New_Customer.Set_Email(Txt_Email.Text.Trim());
                New_Customer.Set_Phone_Number(Txt_Contact.Text.Trim());
                New_Customer.Set_Address(Txt_Address.Text.Trim());
                New_Customer.Set_Plan(Cmb_Plan.SelectedItem.ToString());
                New_Customer.Set_Balance(Balance_Value);
                New_Customer.Set_Savings(0);
                New_Customer.Set_Photo_Path(Photo_Path);
                File_Manager.Save_Customer(New_Customer);
                MessageBox.Show("Customer added successfully!", "Success",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
