using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using oop_project2_Elitegrp.Classes;

namespace oop_project2_Elitegrp.Forms
{
    public class Show_Customer_Form : Form
    {
        private static readonly Color C_Bg      = Color.FromArgb(245, 247, 250);
        private static readonly Color C_Card    = Color.White;
        private static readonly Color C_Primary = Color.FromArgb(79,  110, 171);
        private static readonly Color C_Accent  = Color.FromArgb(230, 236, 250);
        private static readonly Color C_Danger  = Color.FromArgb(195, 75,  75);
        private static readonly Color C_Green   = Color.FromArgb(67,  160, 100);
        private static readonly Color C_Text    = Color.FromArgb(40,  44,  52);
        private static readonly Color C_Key     = Color.FromArgb(80,  95,  130);
        private static readonly Font  F_Title   = new Font("Segoe UI", 16, FontStyle.Bold);
        private static readonly Font  F_Counter = new Font("Segoe UI", 12, FontStyle.Bold);
        private static readonly Font  F_Key     = new Font("Segoe UI", 9,  FontStyle.Bold);
        private static readonly Font  F_Val     = new Font("Segoe UI", 9);
        private static readonly Font  F_Btn     = new Font("Segoe UI", 10, FontStyle.Bold);
        private static readonly Font  F_Btn_Sm  = new Font("Segoe UI", 9,  FontStyle.Bold);

        private Label  Lbl_Title, Lbl_Counter;
        private Button Btn_Prev, Btn_Next;
        private Panel  Pnl_Card;

        private Label  Lbl_Name_Key, Lbl_Name_Val;
        private Label  Lbl_Last_Key, Lbl_Last_Val;
        private Label  Lbl_Email_Key, Lbl_Email_Val;
        private Label  Lbl_Phone_Key, Lbl_Phone_Val;
        private Label  Lbl_Address_Key, Lbl_Address_Val;
        private Label  Lbl_Account_Key, Lbl_Account_Val;
        private Label  Lbl_ID_Key, Lbl_ID_Val;
        private Label  Lbl_Plan_Key, Lbl_Plan_Val;
        private Label  Lbl_Balance_Key, Lbl_Balance_Val;
        private Label  Lbl_Savings_Key, Lbl_Savings_Val;

        private PictureBox Pic_Photo;
        private Button     Btn_Edit, Btn_Control_Balance, Btn_Delete, Btn_Exit;

        private List<Customer> Customer_List;
        private int Current_Index = 0;

      

        private const int FORM_W   = 760;
        private const int CARD_X   = 20;
        private const int CARD_W   = 720;   

        private const int La  = 10;   
        private const int Va  = 118;  
        private const int WVa = 160;  
        private const int Lb  = 288; 
        private const int Vb  = 406;
        private const int WVb = 120;  
        private const int Px  = 546;  
        private const int PW  = 120;  
        private const int PH  = 120;  
        private const int Ry  = 30; 
        private const int Sy  = 32;   

        public Show_Customer_Form()
        {
            Customer_List = File_Manager.Load_Customers();
            Init_Components();
            if (Customer_List.Count > 0) Display_Customer(0);
        }

        private void Init_Components()
        {
            this.Text            = "Show Customer";
            this.StartPosition   = FormStartPosition.CenterScreen;
            this.BackColor       = C_Bg;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox     = false;

        
            Panel Pnl_Header = new Panel();
            Pnl_Header.Size      = new Size(FORM_W, 55);
            Pnl_Header.Location  = new Point(0, 0);
            Pnl_Header.BackColor = C_Primary;

            Lbl_Title = new Label();
            Lbl_Title.Text      = "Show Customer";
            Lbl_Title.Font      = F_Title;
            Lbl_Title.ForeColor = Color.White;
            Lbl_Title.Size      = new Size(FORM_W - 20, 50);
            Lbl_Title.Location  = new Point(10, 3);
            Lbl_Title.TextAlign = ContentAlignment.MiddleCenter;
            Pnl_Header.Controls.Add(Lbl_Title);

            
            int Nav_Btn_W = 34;
            Btn_Prev = Make_Nav_Btn("<", 20, 65);
            Btn_Prev.Click += (s, e) => Navigate(-1);

            Lbl_Counter = new Label();
            Lbl_Counter.Size      = new Size(FORM_W - 20 - Nav_Btn_W * 2 - 20, 30);
            Lbl_Counter.Location  = new Point(20 + Nav_Btn_W + 4, 65);
            Lbl_Counter.TextAlign = ContentAlignment.MiddleCenter;
            Lbl_Counter.Font      = F_Counter;
            Lbl_Counter.ForeColor = C_Primary;

            Btn_Next = Make_Nav_Btn(">", FORM_W - 20 - Nav_Btn_W, 65);
            Btn_Next.Click += (s, e) => Navigate(1);

        
            Pnl_Card = new Panel();
            Pnl_Card.Location  = new Point(CARD_X, 103);
            Pnl_Card.BackColor = C_Card;
            Pnl_Card.Paint    += (s, e) => ControlPaint.DrawBorder(e.Graphics, Pnl_Card.ClientRectangle,
                                     Color.FromArgb(210, 215, 230), ButtonBorderStyle.Solid);

            Panel Pnl_Sec = new Panel();
            Pnl_Sec.Location  = new Point(0, 0);
            Pnl_Sec.BackColor = C_Accent;
            Label Lbl_Sec = new Label();
            Lbl_Sec.Text      = "  Customer Information";
            Lbl_Sec.Font      = new Font("Segoe UI", 9, FontStyle.Bold);
            Lbl_Sec.ForeColor = C_Key;
            Lbl_Sec.Dock      = DockStyle.Fill;
            Lbl_Sec.TextAlign = ContentAlignment.MiddleLeft;
            Pnl_Sec.Controls.Add(Lbl_Sec);

            
            Lbl_Name_Key  = Make_Key("Name:",    La, Sy);
            Lbl_Name_Val  = Make_Val(Va, Sy, WVa);
            Lbl_Plan_Key  = Make_Key("Plan:",    Lb, Sy);
            Lbl_Plan_Val  = Make_Val(Vb, Sy, WVb);

            
            Lbl_Last_Key    = Make_Key("Last Name:",  La, Sy + Ry);
            Lbl_Last_Val    = Make_Val(Va, Sy + Ry, WVa);
            Lbl_Balance_Key = Make_Key("Balance:",    Lb, Sy + Ry);
            Lbl_Balance_Val = Make_Val(Vb, Sy + Ry, WVb);

        
            Lbl_Email_Key   = Make_Key("Email:",   La, Sy + Ry * 2);
            Lbl_Email_Val   = Make_Val(Va, Sy + Ry * 2, WVa);
            Lbl_Savings_Key = Make_Key("Savings:", Lb, Sy + Ry * 2);
            Lbl_Savings_Val = Make_Val(Vb, Sy + Ry * 2, WVb);

            
            Lbl_Phone_Key = Make_Key("Phone:", La, Sy + Ry * 3);
            Lbl_Phone_Val = Make_Val(Va, Sy + Ry * 3, WVa + 20);

            
            Lbl_Address_Key = Make_Key("Address:",    La, Sy + Ry * 4);
            Lbl_Address_Val = Make_Val(Va, Sy + Ry * 4, Px - Va - 10);

        
            Lbl_Account_Key = Make_Key("Account No.:", La, Sy + Ry * 5);
            Lbl_Account_Val = Make_Val(Va, Sy + Ry * 5, Px - Va - 10);

    
            Lbl_ID_Key = Make_Key("Customer ID:", La, Sy + Ry * 6);
            Lbl_ID_Val = Make_Val(Va, Sy + Ry * 6, 200);

            int Rows_Bottom = Sy + Ry * 7;

            
            Pic_Photo = new PictureBox();
            Pic_Photo.Size        = new Size(PW, PH);
            Pic_Photo.Location    = new Point(Px, Sy);
            Pic_Photo.BorderStyle = BorderStyle.FixedSingle;
            Pic_Photo.SizeMode    = PictureBoxSizeMode.Zoom;
            Pic_Photo.BackColor   = Color.FromArgb(220, 225, 235);

            Btn_Edit = new Button();
            Btn_Edit.Text      = "✏ Edit";
            Btn_Edit.Size      = new Size(PW, 32);
            Btn_Edit.Location  = new Point(Px, Sy + PH + 8);
            Btn_Edit.BackColor = C_Accent;
            Btn_Edit.ForeColor = C_Primary;
            Btn_Edit.FlatStyle = FlatStyle.Flat;
            Btn_Edit.FlatAppearance.BorderColor = C_Primary;
            Btn_Edit.Font      = F_Btn_Sm;
            Btn_Edit.Click    += Btn_Edit_Click;

            Btn_Control_Balance = new Button();
            Btn_Control_Balance.Text      = "💳 Balance";
            Btn_Control_Balance.Size      = new Size(PW, 32);
            Btn_Control_Balance.Location  = new Point(Px, Sy + PH + 8 + 38);
            Btn_Control_Balance.BackColor = C_Green;
            Btn_Control_Balance.ForeColor = Color.White;
            Btn_Control_Balance.FlatStyle = FlatStyle.Flat;
            Btn_Control_Balance.FlatAppearance.BorderSize = 0;
            Btn_Control_Balance.Font      = F_Btn_Sm;
            Btn_Control_Balance.Click    += Btn_Control_Balance_Click;

            Btn_Delete = new Button();
            Btn_Delete.Text      = "🗑 Delete";
            Btn_Delete.Size      = new Size(PW, 32);
            Btn_Delete.Location  = new Point(Px, Sy + PH + 8 + 38 + 38);
            Btn_Delete.BackColor = C_Danger;
            Btn_Delete.ForeColor = Color.White;
            Btn_Delete.FlatStyle = FlatStyle.Flat;
            Btn_Delete.FlatAppearance.BorderSize = 0;
            Btn_Delete.Font      = F_Btn_Sm;
            Btn_Delete.Click    += Btn_Delete_Click;

            // Ensure card is tall enough to contain all three right-column buttons
            int Btn_Delete_Bottom = Sy + PH + 8 + 38 + 38 + 32 + 10;
            int Card_Height = Math.Max(Rows_Bottom + 12, Btn_Delete_Bottom);
            Pnl_Sec.Size  = new Size(CARD_W, 26);
            Pnl_Card.Size = new Size(CARD_W, Card_Height);

            Pnl_Card.Controls.AddRange(new Control[] {
                Pnl_Sec,
                Lbl_Name_Key, Lbl_Name_Val, Lbl_Plan_Key, Lbl_Plan_Val,
                Lbl_Last_Key, Lbl_Last_Val, Lbl_Balance_Key, Lbl_Balance_Val,
                Lbl_Email_Key, Lbl_Email_Val, Lbl_Savings_Key, Lbl_Savings_Val,
                Lbl_Phone_Key, Lbl_Phone_Val,
                Lbl_Address_Key, Lbl_Address_Val,
                Lbl_Account_Key, Lbl_Account_Val,
                Lbl_ID_Key, Lbl_ID_Val,
                Pic_Photo, Btn_Edit, Btn_Control_Balance, Btn_Delete
            });

            int Exit_Y = 103 + Card_Height + 10;

            Btn_Exit = new Button();
            Btn_Exit.Text      = "Exit";
            Btn_Exit.Size      = new Size(200, 36);
            Btn_Exit.BackColor = C_Danger;
            Btn_Exit.ForeColor = Color.White;
            Btn_Exit.FlatStyle = FlatStyle.Flat;
            Btn_Exit.FlatAppearance.BorderSize = 0;
            Btn_Exit.Font      = F_Btn;
            Btn_Exit.Click    += (s, e) => this.Close();
            Btn_Exit.Location  = new Point((FORM_W - 200) / 2, Exit_Y);

            this.ClientSize = new Size(FORM_W, Exit_Y + 36 + 14);

            this.Controls.AddRange(new Control[] {
                Pnl_Header, Btn_Prev, Lbl_Counter, Btn_Next, Pnl_Card, Btn_Exit
            });
        }

        private Button Make_Nav_Btn(string Text, int X, int Y)
        {
            Button B = new Button();
            B.Text      = Text;
            B.Size      = new Size(34, 30);
            B.Location  = new Point(X, Y);
            B.BackColor = Color.FromArgb(230, 236, 250);
            B.ForeColor = C_Primary;
            B.FlatStyle = FlatStyle.Flat;
            B.FlatAppearance.BorderColor = C_Primary;
            B.Font      = new Font("Segoe UI", 10, FontStyle.Bold);
            return B;
        }

        private Label Make_Key(string Text, int X, int Y)
        {
            Label L = new Label();
            L.Text      = Text;
            L.Size      = new Size(108, 22);
            L.Location  = new Point(X, Y + 3);
            L.Font      = F_Key;
            L.ForeColor = C_Key;
            return L;
        }

        private Label Make_Val(int X, int Y, int Width)
        {
            Label L = new Label();
            L.Size      = new Size(Width, 22);
            L.Location  = new Point(X, Y + 3);
            L.Font      = F_Val;
            L.ForeColor = C_Text;
            return L;
        }

        private void Display_Customer(int Index)
        {
            if (Customer_List.Count == 0) { Lbl_Counter.Text = "No customers"; return; }
            Customer C = Customer_List[Index];
            Lbl_Counter.Text     = (Index + 1) + "  /  " + Customer_List.Count;
            Lbl_Name_Val.Text    = C.Get_Name();
            Lbl_Last_Val.Text    = C.Get_Last_Name();
            Lbl_Email_Val.Text   = C.Get_Email();
            Lbl_Phone_Val.Text   = C.Get_Phone_Number();
            Lbl_Address_Val.Text = C.Get_Address();
            Lbl_Account_Val.Text = C.Get_Account_Number();
            Lbl_ID_Val.Text      = C.Get_Customer_ID();
            Lbl_Plan_Val.Text    = C.Get_Plan();
            Lbl_Balance_Val.Text = C.Get_Balance().ToString("F2") + " PLN";
            Lbl_Savings_Val.Text = C.Get_Savings().ToString("F2") + " PLN";
            try
            {
                Pic_Photo.Image = null;
                string Full_Path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, C.Get_Photo_Path());
                if (!string.IsNullOrEmpty(C.Get_Photo_Path()) && File.Exists(Full_Path))
                    Pic_Photo.Image = Image.FromFile(Full_Path);
            }
            catch { Pic_Photo.Image = null; }
        }

        private void Navigate(int Direction)
        {
            if (Customer_List.Count == 0) return;
            Current_Index = (Current_Index + Direction + Customer_List.Count) % Customer_List.Count;
            Display_Customer(Current_Index);
        }

        private void Btn_Edit_Click(object sender, EventArgs e)
        {
            if (Customer_List.Count == 0) return;
            new Edit_Customer_Form(Customer_List[Current_Index]).ShowDialog();
            Customer_List = File_Manager.Load_Customers();
            if (Current_Index >= Customer_List.Count) Current_Index = 0;
            if (Customer_List.Count > 0) Display_Customer(Current_Index);
        }

        private void Btn_Control_Balance_Click(object sender, EventArgs e)
        {
            if (Customer_List.Count == 0) return;
            new Account_Control_Form(Customer_List[Current_Index]).ShowDialog();
            Customer_List = File_Manager.Load_Customers();
            if (Current_Index >= Customer_List.Count) Current_Index = 0;
            if (Customer_List.Count > 0) Display_Customer(Current_Index);
        }

        private void Btn_Delete_Click(object sender, EventArgs e)
        {
            if (Customer_List.Count == 0) return;
            Customer C = Customer_List[Current_Index];
            string Name = C.Get_Name() + " " + C.Get_Last_Name();
            DialogResult Confirm = MessageBox.Show(
                "Are you sure you want to delete customer:\n" + Name + "?",
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);
            if (Confirm != DialogResult.Yes) return;

            Customer_List.RemoveAt(Current_Index);
            File_Manager.Update_All_Customers(Customer_List);

            if (Current_Index >= Customer_List.Count) Current_Index = 0;
            if (Customer_List.Count > 0)
                Display_Customer(Current_Index);
            else
                Lbl_Counter.Text = "No customers";
        }
    }
}
