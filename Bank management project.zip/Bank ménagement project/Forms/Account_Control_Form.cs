using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using oop_project2_Elitegrp.Classes;

namespace oop_project2_Elitegrp.Forms
{
    public class Account_Control_Form : Form
    {
        private static readonly Color C_Bg      = Color.FromArgb(245, 247, 250);
        private static readonly Color C_Card    = Color.White;
        private static readonly Color C_Primary = Color.FromArgb(79,  110, 171);
        private static readonly Color C_Accent  = Color.FromArgb(230, 236, 250);
        private static readonly Color C_Green   = Color.FromArgb(67,  160, 100);
        private static readonly Color C_Green_Dk= Color.FromArgb(45,  130, 75);
        private static readonly Color C_Orange  = Color.FromArgb(220, 130, 50);
        private static readonly Color C_Orange_Dk = Color.FromArgb(185, 100, 30);
        private static readonly Color C_Teal    = Color.FromArgb(50,  155, 160);
        private static readonly Color C_Teal_Dk = Color.FromArgb(30,  125, 130);
        private static readonly Color C_Danger  = Color.FromArgb(195, 75,  75);
        private static readonly Color C_Text    = Color.FromArgb(40,  44,  52);
        private static readonly Color C_Key     = Color.FromArgb(80,  95,  130);
        private static readonly Font  F_Title   = new Font("Segoe UI", 15, FontStyle.Bold);
        private static readonly Font  F_Key     = new Font("Segoe UI", 9,  FontStyle.Bold);
        private static readonly Font  F_Val     = new Font("Segoe UI", 9,  FontStyle.Bold);
        private static readonly Font  F_Input   = new Font("Segoe UI", 9);
        private static readonly Font  F_Group   = new Font("Segoe UI", 9,  FontStyle.Bold);
        private static readonly Font  F_Btn     = new Font("Segoe UI", 10, FontStyle.Bold);
        private static readonly Font  F_Btn_Sm  = new Font("Segoe UI", 9,  FontStyle.Bold);

        private Label  Lbl_Title;
        private Label  Lbl_Account_Key, Lbl_Account_Val;
        private Label  Lbl_ID_Key, Lbl_ID_Val;
        private Label  Lbl_Balance_Key, Lbl_Balance_Val;
        private Label  Lbl_Savings_Key, Lbl_Savings_Val;
        private Label  Lbl_Withdraw_Amount, Lbl_Move_Amount, Lbl_Deposit_Amount;
        private TextBox Txt_Withdraw, Txt_Move, Txt_Deposit;
        private Button  Btn_Withdraw, Btn_Move, Btn_Deposit, Btn_Exit;
        private Customer Current_Customer;

        public Account_Control_Form(Customer Customer_Object)
        {
            Current_Customer = Customer_Object;
            Init_Components();
            Refresh_Info();
        }

        private void Init_Components()
        {
            this.Text            = "Account Control";
            this.Size            = new Size(420, 555);
            this.StartPosition   = FormStartPosition.CenterScreen;
            this.BackColor       = C_Bg;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox     = false;

            Panel Pnl_Header = new Panel();
            Pnl_Header.Size      = new Size(420, 55);
            Pnl_Header.Location  = new Point(0, 0);
            Pnl_Header.BackColor = C_Primary;

            Lbl_Title = new Label();
            Lbl_Title.Text      = "Account Control";
            Lbl_Title.Font      = F_Title;
            Lbl_Title.ForeColor = Color.White;
            Lbl_Title.Size      = new Size(400, 50);
            Lbl_Title.Location  = new Point(10, 3);
            Lbl_Title.TextAlign = ContentAlignment.MiddleCenter;
            Pnl_Header.Controls.Add(Lbl_Title);

            
            Panel Pnl_Info = new Panel();
            Pnl_Info.Size      = new Size(380, 110);
            Pnl_Info.Location  = new Point(20, 65);
            Pnl_Info.BackColor = C_Card;
            Pnl_Info.Paint    += (s, e) => ControlPaint.DrawBorder(e.Graphics, Pnl_Info.ClientRectangle,
                                    Color.FromArgb(210, 215, 230), ButtonBorderStyle.Solid);

            Panel Pnl_Info_Hdr = new Panel();
            Pnl_Info_Hdr.Size      = new Size(380, 24);
            Pnl_Info_Hdr.Location  = new Point(0, 0);
            Pnl_Info_Hdr.BackColor = C_Accent;
            Label Lbl_Info_Title = new Label();
            Lbl_Info_Title.Text      = "  Account Info";
            Lbl_Info_Title.Font      = F_Group;
            Lbl_Info_Title.ForeColor = C_Key;
            Lbl_Info_Title.Size      = new Size(380, 24);
            Lbl_Info_Title.TextAlign = ContentAlignment.MiddleLeft;
            Pnl_Info_Hdr.Controls.Add(Lbl_Info_Title);

            Lbl_Account_Key = Make_Key("Account:",     10, 30);
            Lbl_Account_Val = Make_Val(90, 30, 200);
            Lbl_ID_Key      = Make_Key("Customer ID:", 10, 52);
            Lbl_ID_Val      = Make_Val(90, 52, 100);
            Lbl_Balance_Key = Make_Key("Balance:",     10, 74);
            Lbl_Balance_Val = Make_Val(90, 74, 100);
            Lbl_Savings_Key = Make_Key("Savings:",     210, 74);
            Lbl_Savings_Val = Make_Val(280, 74, 100);

            Pnl_Info.Controls.AddRange(new Control[] {
                Pnl_Info_Hdr,
                Lbl_Account_Key, Lbl_Account_Val,
                Lbl_ID_Key, Lbl_ID_Val,
                Lbl_Balance_Key, Lbl_Balance_Val,
                Lbl_Savings_Key, Lbl_Savings_Val
            });

           
            int Op_Y = 190;
            Panel Pnl_Withdraw = Make_Op_Panel("💸  Withdraw", Op_Y, C_Danger);
            (Lbl_Withdraw_Amount, Txt_Withdraw, Btn_Withdraw) = Fill_Op_Panel(Pnl_Withdraw, "Amount:", C_Danger, Color.FromArgb(165, 50, 50));
            Btn_Withdraw.Click += Btn_Withdraw_Click;

            Panel Pnl_Move = Make_Op_Panel("💼  Move to Savings", Op_Y + 115, C_Orange);
            (Lbl_Move_Amount, Txt_Move, Btn_Move) = Fill_Op_Panel(Pnl_Move, "Amount:", C_Orange, C_Orange_Dk);
            Btn_Move.Click += Btn_Move_Click;

            Panel Pnl_Deposit = Make_Op_Panel("💰  Deposit", Op_Y + 230, C_Green);
            (Lbl_Deposit_Amount, Txt_Deposit, Btn_Deposit) = Fill_Op_Panel(Pnl_Deposit, "Amount:", C_Green, C_Green_Dk);
            Btn_Deposit.Click += Btn_Deposit_Click;

            Btn_Exit = new Button();
            Btn_Exit.Text      = "Exit";
            Btn_Exit.Size      = new Size(180, 36);
            Btn_Exit.Location  = new Point(120, 482);
            Btn_Exit.BackColor = C_Danger;
            Btn_Exit.ForeColor = Color.White;
            Btn_Exit.FlatStyle = FlatStyle.Flat;
            Btn_Exit.FlatAppearance.BorderSize = 0;
            Btn_Exit.Font      = F_Btn;
            Btn_Exit.Click    += (s, e) => this.Close();

            this.Controls.AddRange(new Control[] {
                Pnl_Header, Pnl_Info, Pnl_Withdraw, Pnl_Move, Pnl_Deposit, Btn_Exit
            });
        }

        private Panel Make_Op_Panel(string Title, int Y, Color Accent_Color)
        {
            Panel P = new Panel();
            P.Size      = new Size(380, 100);
            P.Location  = new Point(20, Y);
            P.BackColor = C_Card;
            P.Paint    += (s, e) => ControlPaint.DrawBorder(e.Graphics, P.ClientRectangle,
                              Color.FromArgb(210, 215, 230), ButtonBorderStyle.Solid);

            Panel Hdr = new Panel();
            Hdr.Size      = new Size(380, 24);
            Hdr.Location  = new Point(0, 0);
            Hdr.BackColor = Color.FromArgb(Accent_Color.R + (255 - Accent_Color.R) * 8 / 10,
                                           Accent_Color.G + (255 - Accent_Color.G) * 8 / 10,
                                           Accent_Color.B + (255 - Accent_Color.B) * 8 / 10);

          
            Hdr.BackColor = Color.FromArgb(245, 248, 252);

            Label Lbl = new Label();
            Lbl.Text      = "  " + Title;
            Lbl.Font      = F_Group;
            Lbl.ForeColor = C_Key;
            Lbl.Size      = new Size(380, 24);
            Lbl.TextAlign = ContentAlignment.MiddleLeft;
            Hdr.Controls.Add(Lbl);
            P.Controls.Add(Hdr);
            return P;
        }

        private (Label, TextBox, Button) Fill_Op_Panel(Panel P, string Lbl_Text, Color Btn_Color, Color Btn_Hover)
        {
            Label Lbl = new Label();
            Lbl.Text      = Lbl_Text;
            Lbl.Size      = new Size(65, 22);
            Lbl.Location  = new Point(12, 45);
            Lbl.Font      = new Font("Segoe UI", 9, FontStyle.Bold);
            Lbl.ForeColor = C_Key;

            TextBox Txt = new TextBox();
            Txt.Size      = new Size(170, 24);
            Txt.Location  = new Point(80, 44);
            Txt.Font      = F_Input;

            Button Btn = new Button();
            Btn.Size      = new Size(100, 30);
            Btn.Location  = new Point(265, 42);
            Btn.BackColor = Btn_Color;
            Btn.ForeColor = Color.White;
            Btn.FlatStyle = FlatStyle.Flat;
            Btn.FlatAppearance.BorderSize = 0;
            Btn.Font      = F_Btn_Sm;
            Btn.Text      = "Confirm";
            Btn.MouseEnter += (s, e) => ((Button)s).BackColor = Btn_Hover;
            Btn.MouseLeave += (s, e) => ((Button)s).BackColor = Btn_Color;

            P.Controls.AddRange(new Control[] { Lbl, Txt, Btn });
            return (Lbl, Txt, Btn);
        }

        private Label Make_Key(string Text, int X, int Y)
        {
            Label L = new Label();
            L.Text      = Text;
            L.Size      = new Size(80, 20);
            L.Location  = new Point(X, Y);
            L.Font      = F_Key;
            L.ForeColor = C_Key;
            return L;
        }

        private Label Make_Val(int X, int Y, int Width)
        {
            Label L = new Label();
            L.Size      = new Size(Width, 20);
            L.Location  = new Point(X, Y);
            L.Font      = F_Val;
            L.ForeColor = C_Primary;
            return L;
        }

        private void Refresh_Info()
        {
            Lbl_Account_Val.Text = Current_Customer.Get_Account_Number();
            Lbl_ID_Val.Text      = Current_Customer.Get_Customer_ID();
            Lbl_Balance_Val.Text = Current_Customer.Get_Balance().ToString("F2") + " PLN";
            Lbl_Savings_Val.Text = Current_Customer.Get_Savings().ToString("F2") + " PLN";
        }

        private void Save_Changes()
        {
            List<Customer> Customer_List = File_Manager.Load_Customers();
            int Index = Customer_List.FindIndex(c => c.Get_Customer_ID() == Current_Customer.Get_Customer_ID());
            if (Index >= 0) Customer_List[Index] = Current_Customer;
            File_Manager.Update_All_Customers(Customer_List);
            Refresh_Info();
        }

        private void Btn_Withdraw_Click(object sender, EventArgs e)
        {
            try
            {
                double Amount;
                if (!double.TryParse(Txt_Withdraw.Text, out Amount) || Amount <= 0)
                { MessageBox.Show("Please enter a valid positive amount!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                if (Amount > Current_Customer.Get_Balance())
                { MessageBox.Show("Insufficient balance!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                Current_Customer.Set_Balance(Current_Customer.Get_Balance() - Amount);
                Save_Changes(); Txt_Withdraw.Clear();
                MessageBox.Show("Withdrawal successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
        }

        private void Btn_Move_Click(object sender, EventArgs e)
        {
            try
            {
                double Amount;
                if (!double.TryParse(Txt_Move.Text, out Amount) || Amount <= 0)
                { MessageBox.Show("Please enter a valid positive amount!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                if (Amount > Current_Customer.Get_Balance())
                { MessageBox.Show("Insufficient balance to move!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                Current_Customer.Set_Balance(Current_Customer.Get_Balance() - Amount);
                Current_Customer.Set_Savings(Current_Customer.Get_Savings() + Amount);
                Save_Changes(); Txt_Move.Clear();
                MessageBox.Show("Amount moved to savings!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
        }

        private void Btn_Deposit_Click(object sender, EventArgs e)
        {
            try
            {
                double Amount;
                if (!double.TryParse(Txt_Deposit.Text, out Amount) || Amount <= 0)
                { MessageBox.Show("Please enter a valid positive amount!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                Current_Customer.Set_Balance(Current_Customer.Get_Balance() + Amount);
                Save_Changes(); Txt_Deposit.Clear();
                MessageBox.Show("Deposit successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
        }
    }
}
