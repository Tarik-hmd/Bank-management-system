using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using oop_project2_Elitegrp.Classes;

namespace oop_project2_Elitegrp.Forms
{
    public class Staff_Control_Form : Form
    {
        private static readonly Color C_Bg      = Color.FromArgb(245, 247, 250);
        private static readonly Color C_Card    = Color.White;
        private static readonly Color C_Primary = Color.FromArgb(79,  110, 171);
        private static readonly Color C_Accent  = Color.FromArgb(230, 236, 250);
        private static readonly Color C_Green   = Color.FromArgb(67,  160, 100);
        private static readonly Color C_Green_Dk= Color.FromArgb(45,  130, 75);
        private static readonly Color C_Orange  = Color.FromArgb(220, 130, 50);
        private static readonly Color C_Orange_Dk = Color.FromArgb(185, 100, 30);
        private static readonly Color C_Danger  = Color.FromArgb(195, 75,  75);
        private static readonly Color C_Key     = Color.FromArgb(80,  95,  130);
        private static readonly Font  F_Title   = new Font("Segoe UI", 15, FontStyle.Bold);
        private static readonly Font  F_Group   = new Font("Segoe UI", 9,  FontStyle.Bold);
        private static readonly Font  F_Key     = new Font("Segoe UI", 9,  FontStyle.Bold);
        private static readonly Font  F_Val     = new Font("Segoe UI", 9,  FontStyle.Bold);
        private static readonly Font  F_Input   = new Font("Segoe UI", 9);
        private static readonly Font  F_Btn     = new Font("Segoe UI", 10, FontStyle.Bold);
        private static readonly Font  F_Btn_Sm  = new Font("Segoe UI", 9,  FontStyle.Bold);

        private Label   Lbl_Title;
        private Label   Lbl_ID_Key, Lbl_ID_Val;
        private Label   Lbl_Unpaid_Hours_Key, Lbl_Unpaid_Hours_Val;
        private Label   Lbl_Extra_Hours_Key, Lbl_Extra_Hours_Val;
        private Label   Lbl_Unpaid_Balance_Key, Lbl_Unpaid_Balance_Val;
        private Button  Btn_Pay;
        private Label   Lbl_Normal_Hour, Lbl_Extra_Hour;
        private TextBox Txt_Normal_Hour, Txt_Extra_Hour;
        private Button  Btn_Add_Hours, Btn_Exit;
        private Staff   Current_Staff;

        public Staff_Control_Form(Staff Staff_Object)
        {
            Current_Staff = Staff_Object;
            Init_Components();
            Refresh_Info();
        }

        private void Init_Components()
        {
            this.Text            = "Staff Control";
            this.Size            = new Size(400, 470);
            this.StartPosition   = FormStartPosition.CenterScreen;
            this.BackColor       = C_Bg;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox     = false;

            Panel Pnl_Header = new Panel();
            Pnl_Header.Size      = new Size(400, 55);
            Pnl_Header.Location  = new Point(0, 0);
            Pnl_Header.BackColor = C_Primary;

            Lbl_Title = new Label();
            Lbl_Title.Text      = "Staff Control";
            Lbl_Title.Font      = F_Title;
            Lbl_Title.ForeColor = Color.White;
            Lbl_Title.Size      = new Size(380, 50);
            Lbl_Title.Location  = new Point(10, 3);
            Lbl_Title.TextAlign = ContentAlignment.MiddleCenter;
            Pnl_Header.Controls.Add(Lbl_Title);

            
            Panel Pnl_Info = new Panel();
            Pnl_Info.Size      = new Size(360, 155);
            Pnl_Info.Location  = new Point(20, 68);
            Pnl_Info.BackColor = C_Card;
            Pnl_Info.Paint    += (s, e) => ControlPaint.DrawBorder(e.Graphics, Pnl_Info.ClientRectangle,
                                    Color.FromArgb(210, 215, 230), ButtonBorderStyle.Solid);

            Panel Pnl_Info_Hdr = new Panel();
            Pnl_Info_Hdr.Size      = new Size(360, 24);
            Pnl_Info_Hdr.Location  = new Point(0, 0);
            Pnl_Info_Hdr.BackColor = C_Accent;
            Label Lbl_Info_Title = new Label();
            Lbl_Info_Title.Text      = "  Account Info";
            Lbl_Info_Title.Font      = F_Group;
            Lbl_Info_Title.ForeColor = C_Key;
            Lbl_Info_Title.Size      = new Size(360, 24);
            Lbl_Info_Title.TextAlign = ContentAlignment.MiddleLeft;
            Pnl_Info_Hdr.Controls.Add(Lbl_Info_Title);

            Lbl_ID_Key             = Make_Key("Staff ID:",        10, 32);
            Lbl_ID_Val             = Make_Val(155, 32);
            Lbl_Unpaid_Hours_Key   = Make_Key("Unpaid Hours:",    10, 58);
            Lbl_Unpaid_Hours_Val   = Make_Val(155, 58);
            Lbl_Extra_Hours_Key    = Make_Key("Extra Hours:",     10, 84);
            Lbl_Extra_Hours_Val    = Make_Val(155, 84);
            Lbl_Unpaid_Balance_Key = Make_Key("Unpaid Balance:",  10, 110);
            Lbl_Unpaid_Balance_Val = Make_Val(155, 110);

            Btn_Pay = new Button();
            Btn_Pay.Text      = "💵 Pay";
            Btn_Pay.Size      = new Size(90, 60);
            Btn_Pay.Location  = new Point(255, 52);
            Btn_Pay.BackColor = C_Green;
            Btn_Pay.ForeColor = Color.White;
            Btn_Pay.FlatStyle = FlatStyle.Flat;
            Btn_Pay.FlatAppearance.BorderSize = 0;
            Btn_Pay.Font      = F_Btn;
            Btn_Pay.Cursor    = Cursors.Hand;
            Btn_Pay.MouseEnter += (s, e) => ((Button)s).BackColor = C_Green_Dk;
            Btn_Pay.MouseLeave += (s, e) => ((Button)s).BackColor = C_Green;
            Btn_Pay.Click     += Btn_Pay_Click;

            Pnl_Info.Controls.AddRange(new Control[] {
                Pnl_Info_Hdr,
                Lbl_ID_Key, Lbl_ID_Val,
                Lbl_Unpaid_Hours_Key, Lbl_Unpaid_Hours_Val,
                Lbl_Extra_Hours_Key, Lbl_Extra_Hours_Val,
                Lbl_Unpaid_Balance_Key, Lbl_Unpaid_Balance_Val,
                Btn_Pay
            });

            
            Panel Pnl_Hours = new Panel();
            Pnl_Hours.Size      = new Size(360, 130);
            Pnl_Hours.Location  = new Point(20, 238);
            Pnl_Hours.BackColor = C_Card;
            Pnl_Hours.Paint    += (s, e) => ControlPaint.DrawBorder(e.Graphics, Pnl_Hours.ClientRectangle,
                                     Color.FromArgb(210, 215, 230), ButtonBorderStyle.Solid);

            Panel Pnl_Hours_Hdr = new Panel();
            Pnl_Hours_Hdr.Size      = new Size(360, 24);
            Pnl_Hours_Hdr.Location  = new Point(0, 0);
            Pnl_Hours_Hdr.BackColor = C_Accent;
            Label Lbl_Hours_Title = new Label();
            Lbl_Hours_Title.Text      = "  Add Hours";
            Lbl_Hours_Title.Font      = F_Group;
            Lbl_Hours_Title.ForeColor = C_Key;
            Lbl_Hours_Title.Size      = new Size(360, 24);
            Lbl_Hours_Title.TextAlign = ContentAlignment.MiddleLeft;
            Pnl_Hours_Hdr.Controls.Add(Lbl_Hours_Title);

            Lbl_Normal_Hour = new Label();
            Lbl_Normal_Hour.Text      = "Normal Hours:";
            Lbl_Normal_Hour.Size      = new Size(105, 22);
            Lbl_Normal_Hour.Location  = new Point(12, 40);
            Lbl_Normal_Hour.Font      = F_Key;
            Lbl_Normal_Hour.ForeColor = C_Key;

            Txt_Normal_Hour = new TextBox();
            Txt_Normal_Hour.Size     = new Size(120, 24);
            Txt_Normal_Hour.Location = new Point(120, 39);
            Txt_Normal_Hour.Font     = F_Input;

            Lbl_Extra_Hour = new Label();
            Lbl_Extra_Hour.Text      = "Extra Hours:";
            Lbl_Extra_Hour.Size      = new Size(105, 22);
            Lbl_Extra_Hour.Location  = new Point(12, 72);
            Lbl_Extra_Hour.Font      = F_Key;
            Lbl_Extra_Hour.ForeColor = C_Key;

            Txt_Extra_Hour = new TextBox();
            Txt_Extra_Hour.Size     = new Size(120, 24);
            Txt_Extra_Hour.Location = new Point(120, 71);
            Txt_Extra_Hour.Font     = F_Input;

            Btn_Add_Hours = new Button();
            Btn_Add_Hours.Text      = "Add Hours";
            Btn_Add_Hours.Size      = new Size(90, 58);
            Btn_Add_Hours.Location  = new Point(255, 37);
            Btn_Add_Hours.BackColor = C_Orange;
            Btn_Add_Hours.ForeColor = Color.White;
            Btn_Add_Hours.FlatStyle = FlatStyle.Flat;
            Btn_Add_Hours.FlatAppearance.BorderSize = 0;
            Btn_Add_Hours.Font      = F_Btn_Sm;
            Btn_Add_Hours.Cursor    = Cursors.Hand;
            Btn_Add_Hours.MouseEnter += (s, e) => ((Button)s).BackColor = C_Orange_Dk;
            Btn_Add_Hours.MouseLeave += (s, e) => ((Button)s).BackColor = C_Orange;
            Btn_Add_Hours.Click     += Btn_Add_Hours_Click;

            Pnl_Hours.Controls.AddRange(new Control[] {
                Pnl_Hours_Hdr,
                Lbl_Normal_Hour, Txt_Normal_Hour,
                Lbl_Extra_Hour, Txt_Extra_Hour,
                Btn_Add_Hours
            });

            Btn_Exit = new Button();
            Btn_Exit.Text      = "Exit";
            Btn_Exit.Size      = new Size(180, 36);
            Btn_Exit.Location  = new Point(110, 393);
            Btn_Exit.BackColor = C_Danger;
            Btn_Exit.ForeColor = Color.White;
            Btn_Exit.FlatStyle = FlatStyle.Flat;
            Btn_Exit.FlatAppearance.BorderSize = 0;
            Btn_Exit.Font      = F_Btn;
            Btn_Exit.Click    += (s, e) => this.Close();

            this.Controls.AddRange(new Control[] {
                Pnl_Header, Pnl_Info, Pnl_Hours, Btn_Exit
            });
        }

        private Label Make_Key(string Text, int X, int Y)
        {
            Label L = new Label();
            L.Text      = Text;
            L.Size      = new Size(140, 20);
            L.Location  = new Point(X, Y);
            L.Font      = F_Key;
            L.ForeColor = C_Key;
            return L;
        }

        private Label Make_Val(int X, int Y)
        {
            Label L = new Label();
            L.Size      = new Size(100, 20);
            L.Location  = new Point(X, Y);
            L.Font      = F_Val;
            L.ForeColor = C_Primary;
            return L;
        }

        private void Refresh_Info()
        {
            Lbl_ID_Val.Text             = Current_Staff.Get_Staff_ID();
            Lbl_Unpaid_Hours_Val.Text   = Current_Staff.Get_Normal_Hours().ToString();
            Lbl_Extra_Hours_Val.Text    = Current_Staff.Get_Extra_Hours().ToString();
            Lbl_Unpaid_Balance_Val.Text = Current_Staff.Calculate_Unpaid_Salary().ToString("F2") + " PLN";
        }

        private void Save_Staff_Changes()
        {
            List<Staff> Staff_List = File_Manager.Load_Staff();
            int Index = Staff_List.FindIndex(s => s.Get_Staff_ID() == Current_Staff.Get_Staff_ID());
            if (Index >= 0) Staff_List[Index] = Current_Staff;
            File_Manager.Update_All_Staff(Staff_List);
            Refresh_Info();
        }

        private void Btn_Add_Hours_Click(object sender, EventArgs e)
        {
            try
            {
                int Normal_Hours_To_Add = 0, Extra_Hours_To_Add = 0;
                if (!string.IsNullOrWhiteSpace(Txt_Normal_Hour.Text))
                {
                    if (!int.TryParse(Txt_Normal_Hour.Text, out Normal_Hours_To_Add) || Normal_Hours_To_Add < 0)
                    { MessageBox.Show("Normal hours must be a valid non-negative integer!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                }
                if (!string.IsNullOrWhiteSpace(Txt_Extra_Hour.Text))
                {
                    if (!int.TryParse(Txt_Extra_Hour.Text, out Extra_Hours_To_Add) || Extra_Hours_To_Add < 0)
                    { MessageBox.Show("Extra hours must be a valid non-negative integer!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                }
                Current_Staff.Set_Normal_Hours(Current_Staff.Get_Normal_Hours() + Normal_Hours_To_Add);
                Current_Staff.Set_Extra_Hours(Current_Staff.Get_Extra_Hours() + Extra_Hours_To_Add);
                Save_Staff_Changes();
                Txt_Normal_Hour.Clear(); Txt_Extra_Hour.Clear();
                MessageBox.Show("Hours added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void Btn_Pay_Click(object sender, EventArgs e)
        {
            try
            {
                double Salary_To_Pay = Current_Staff.Calculate_Unpaid_Salary();
                if (Salary_To_Pay <= 0)
                { MessageBox.Show("No unpaid hours to process!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
                DialogResult Result = MessageBox.Show(
                    string.Format("Pay {0:F2} PLN to {1} {2}?", Salary_To_Pay, Current_Staff.Get_Name(), Current_Staff.Get_Last_Name()),
                    "Confirm Payment", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (Result == DialogResult.Yes)
                {
                    Current_Staff.Set_Staff_Balance(Current_Staff.Get_Staff_Balance() + Salary_To_Pay);
                    Current_Staff.Set_Normal_Hours(0);
                    Current_Staff.Set_Extra_Hours(0);
                    Save_Staff_Changes();
                    MessageBox.Show(string.Format("Payment of {0:F2} PLN processed successfully!", Salary_To_Pay),
                        "Payment Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex) { MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }
    }
}
