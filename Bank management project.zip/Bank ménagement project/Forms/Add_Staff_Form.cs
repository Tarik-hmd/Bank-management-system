using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using oop_project2_Elitegrp.Classes;

namespace oop_project2_Elitegrp.Forms
{
    public class Add_Staff_Form : Form
    {
        private static readonly Color C_Bg        = Color.FromArgb(245, 247, 250);
        private static readonly Color C_Primary   = Color.FromArgb(79,  110, 171);
        private static readonly Color C_Green     = Color.FromArgb(67,  160, 100);
        private static readonly Color C_Green_Dk  = Color.FromArgb(45,  130, 75);
        private static readonly Color C_Danger    = Color.FromArgb(195, 75,  75);
        private static readonly Color C_Danger_Dk = Color.FromArgb(165, 50,  50);
        private static readonly Color C_Text      = Color.FromArgb(40,  44,  52);
        private static readonly Color C_Badge     = Color.FromArgb(230, 236, 250);
        private static readonly Font  F_Title     = new Font("Segoe UI", 15, FontStyle.Bold);
        private static readonly Font  F_Label     = new Font("Segoe UI", 9,  FontStyle.Bold);
        private static readonly Font  F_Input     = new Font("Segoe UI", 9);
        private static readonly Font  F_Btn       = new Font("Segoe UI", 10, FontStyle.Bold);

        private Label    Lbl_Title, Lbl_Staff_ID_Label, Lbl_ID_Value;
        private Label    Lbl_Name, Lbl_Last_Name, Lbl_Contact, Lbl_Email, Lbl_Address, Lbl_Role;
        private TextBox  Txt_Name, Txt_Last_Name, Txt_Contact, Txt_Email, Txt_Address;
        private ComboBox Cmb_Role;
        private PictureBox Pic_Photo;
        private Button   Btn_Browse, Btn_Save, Btn_Cancel;

        private string      Photo_Path = "";
        private List<Staff> Staff_List;
        private string      Generated_ID;

        public Add_Staff_Form()
        {
            Staff_List   = File_Manager.Load_Staff();
            Generated_ID = ID_Generator.Generate_Staff_ID(Staff_List);
            Init_Components();
        }

        private void Init_Components()
        {
            this.Text            = "Add Staff";
            this.Size            = new Size(530, 100); 
            this.StartPosition   = FormStartPosition.CenterScreen;
            this.BackColor       = C_Bg;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox     = false;

           
            Panel Pnl_Header = new Panel();
            Pnl_Header.Size      = new Size(530, 55);
            Pnl_Header.Location  = new Point(0, 0);
            Pnl_Header.BackColor = C_Primary;

            Lbl_Title = new Label();
            Lbl_Title.Text      = "Add Staff";
            Lbl_Title.Font      = F_Title;
            Lbl_Title.ForeColor = Color.White;
            Lbl_Title.Size      = new Size(510, 50);
            Lbl_Title.Location  = new Point(10, 3);
            Lbl_Title.TextAlign = ContentAlignment.MiddleCenter;
            Pnl_Header.Controls.Add(Lbl_Title);

          
            Panel Pnl_ID = new Panel();
            Pnl_ID.Size      = new Size(210, 30);
            Pnl_ID.Location  = new Point(20, 65);
            Pnl_ID.BackColor = C_Badge;

            Lbl_Staff_ID_Label = new Label();
            Lbl_Staff_ID_Label.Text      = "Staff ID:";
            Lbl_Staff_ID_Label.Size      = new Size(60, 20);
            Lbl_Staff_ID_Label.Location  = new Point(6, 6);
            Lbl_Staff_ID_Label.Font      = new Font("Segoe UI", 8, FontStyle.Bold);
            Lbl_Staff_ID_Label.ForeColor = Color.FromArgb(100, 115, 145);

            Lbl_ID_Value = new Label();
            Lbl_ID_Value.Text      = Generated_ID;
            Lbl_ID_Value.Size      = new Size(130, 20);
            Lbl_ID_Value.Location  = new Point(68, 6);
            Lbl_ID_Value.Font      = new Font("Segoe UI", 9, FontStyle.Bold);
            Lbl_ID_Value.ForeColor = C_Primary;
            Pnl_ID.Controls.AddRange(new Control[] { Lbl_Staff_ID_Label, Lbl_ID_Value });

         
            Pic_Photo = new PictureBox();
            Pic_Photo.Size        = new Size(100, 100);
            Pic_Photo.Location    = new Point(405, 65);
            Pic_Photo.BorderStyle = BorderStyle.FixedSingle;
            Pic_Photo.SizeMode    = PictureBoxSizeMode.Zoom;
            Pic_Photo.BackColor   = Color.FromArgb(220, 225, 235);

            Btn_Browse = new Button();
            Btn_Browse.Text      = "📷 Browse";
            Btn_Browse.Size      = new Size(100, 26);
            Btn_Browse.Location  = new Point(405, 170);
            Btn_Browse.BackColor = C_Badge;
            Btn_Browse.ForeColor = C_Primary;
            Btn_Browse.FlatStyle = FlatStyle.Flat;
            Btn_Browse.FlatAppearance.BorderColor = C_Primary;
            Btn_Browse.Font      = new Font("Segoe UI", 8, FontStyle.Bold);
            Btn_Browse.Click    += Btn_Browse_Click;

            
            int Lx = 20, Ix = 120, W = 265, Ry = 36, Sy = 105;

            Lbl_Name      = Make_Label("Name:",      Lx, Sy);
            Txt_Name      = Make_Input(Ix, Sy, W);

            Lbl_Last_Name = Make_Label("Last Name:", Lx, Sy + Ry);
            Txt_Last_Name = Make_Input(Ix, Sy + Ry, W);

            Lbl_Contact   = Make_Label("Contact:",   Lx, Sy + Ry * 2);
            Txt_Contact   = Make_Input(Ix, Sy + Ry * 2, W);

            Lbl_Email     = Make_Label("Email:",     Lx, Sy + Ry * 3);
            Txt_Email     = Make_Input(Ix, Sy + Ry * 3, W);

            Lbl_Address   = Make_Label("Address:",   Lx, Sy + Ry * 4);
            Txt_Address   = Make_Input(Ix, Sy + Ry * 4, W);

            
            Lbl_Role = Make_Label("Role:", Lx, Sy + Ry * 5);
            Cmb_Role = new ComboBox();
            Cmb_Role.Size          = new Size(265, 26);
            Cmb_Role.Location      = new Point(Ix, Sy + Ry * 5 + 2);
            Cmb_Role.DropDownStyle = ComboBoxStyle.DropDownList;
            Cmb_Role.Font          = F_Input;
            foreach (string Role_Name in Salary_Calculator.Get_Roles())
                Cmb_Role.Items.Add(Role_Name);
            Cmb_Role.SelectedIndex = 0;

            
            int Btn_Y = Sy + Ry * 6 + 14;

            Btn_Save   = Make_Action_Button("✔  Save",   20,  Btn_Y, C_Green,  C_Green_Dk);
            Btn_Cancel = Make_Action_Button("✖  Cancel", 390, Btn_Y, C_Danger, C_Danger_Dk);
            Btn_Save.Click   += Btn_Save_Click;
            Btn_Cancel.Click += (s, e) => this.Close();

            this.ClientSize = new Size(530, Btn_Y + 36 + 14);

            this.Controls.AddRange(new Control[] {
                Pnl_Header, Pnl_ID, Pic_Photo, Btn_Browse,
                Lbl_Name, Txt_Name, Lbl_Last_Name, Txt_Last_Name,
                Lbl_Contact, Txt_Contact, Lbl_Email, Txt_Email,
                Lbl_Address, Txt_Address, Lbl_Role, Cmb_Role,
                Btn_Save, Btn_Cancel
            });
        }

        private Label Make_Label(string Text, int X, int Y)
        {
            Label L = new Label();
            L.Text      = Text;
            L.Size      = new Size(98, 22);
            L.Location  = new Point(X, Y + 4);
            L.Font      = F_Label;
            L.ForeColor = C_Text;
            return L;
        }

        private TextBox Make_Input(int X, int Y, int Width)
        {
            TextBox T = new TextBox();
            T.Size        = new Size(Width, 24);
            T.Location    = new Point(X, Y + 2);
            T.Font        = F_Input;
            T.BorderStyle = BorderStyle.FixedSingle;
            return T;
        }

        private Button Make_Action_Button(string Text, int X, int Y, Color Bg, Color Hover)
        {
            Button B = new Button();
            B.Text      = Text;
            B.Size      = new Size(115, 36);
            B.Location  = new Point(X, Y);
            B.BackColor = Bg;
            B.ForeColor = Color.White;
            B.FlatStyle = FlatStyle.Flat;
            B.FlatAppearance.BorderSize = 0;
            B.Font      = F_Btn;
            B.Cursor    = Cursors.Hand;
            B.MouseEnter += (s, e) => ((Button)s).BackColor = Hover;
            B.MouseLeave += (s, e) => ((Button)s).BackColor = Bg;
            return B;
        }

        private void Btn_Browse_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog Dlg = new OpenFileDialog();
                Dlg.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";
                if (Dlg.ShowDialog() == DialogResult.OK)
                {
                    string Dest_Folder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Photos");
                    Directory.CreateDirectory(Dest_Folder);
                    string Dest_File = Path.Combine(Dest_Folder, Path.GetFileName(Dlg.FileName));
                    File.Copy(Dlg.FileName, Dest_File, true);
                    Photo_Path = "Photos\\" + Path.GetFileName(Dlg.FileName);
                    Pic_Photo.Image = Image.FromFile(Dest_File);
                }
            }
            catch (Exception ex) { MessageBox.Show("Error loading photo: " + ex.Message); }
        }

        private void Btn_Save_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(Txt_Name.Text) || string.IsNullOrWhiteSpace(Txt_Last_Name.Text))
                {
                    MessageBox.Show("Name and Last Name are required!", "Validation Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                string Selected_Role = Cmb_Role.SelectedItem.ToString();
                Staff New_Staff = new Staff();
                New_Staff.Set_Staff_ID(Generated_ID);
                New_Staff.Set_Name(Txt_Name.Text.Trim());
                New_Staff.Set_Last_Name(Txt_Last_Name.Text.Trim());
                New_Staff.Set_Email(Txt_Email.Text.Trim());
                New_Staff.Set_Phone_Number(Txt_Contact.Text.Trim());
                New_Staff.Set_Address(Txt_Address.Text.Trim());
                New_Staff.Set_Role(Selected_Role);
                New_Staff.Set_Salary_Per_Hour(Salary_Calculator.Get_Salary_For_Role(Selected_Role));
                New_Staff.Set_Staff_Balance(0);
                New_Staff.Set_Normal_Hours(0);
                New_Staff.Set_Extra_Hours(0);
                New_Staff.Set_Photo_Path(Photo_Path);
                File_Manager.Save_Staff(New_Staff);
                MessageBox.Show("Staff member added successfully!", "Success",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
