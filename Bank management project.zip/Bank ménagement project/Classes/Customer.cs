using System;

namespace oop_project2_Elitegrp.Classes
{
    public class Customer : Person
    {
        private string Customer_ID;
        private string Account_Number;
        private string Plan;
        private double Balance;
        private double Savings;

        public string Get_Customer_ID() { return Customer_ID; }
        public void Set_Customer_ID(string value) { Customer_ID = value; }

        public string Get_Account_Number() { return Account_Number; }
        public void Set_Account_Number(string value) { Account_Number = value; }

        public string Get_Plan() { return Plan; }
        public void Set_Plan(string value) { Plan = value; }

        public double Get_Balance() { return Balance; }
        public void Set_Balance(double value) { Balance = value; }

        public double Get_Savings() { return Savings; }
        public void Set_Savings(double value) { Savings = value; }
    }
}
