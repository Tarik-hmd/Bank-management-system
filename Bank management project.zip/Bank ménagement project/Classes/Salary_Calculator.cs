using System;
using System.Collections.Generic;

namespace oop_project2_Elitegrp.Classes
{
    internal static class Salary_Calculator
    {
       
        private static Dictionary<string, double> Role_Salaries = new Dictionary<string, double>
        {
            { "General Manager",  100.0 },
            { "Company CTO",      130.0 },
            { "Branch Manager",    80.0 },
            { "Senior Accountant", 60.0 },
            { "Teller",            40.0 }
        };

        public static List<string> Get_Roles()
        {
            return new List<string>(Role_Salaries.Keys);
        }

        public static double Get_Salary_For_Role(string Role)
        {
            if (Role_Salaries.ContainsKey(Role))
                return Role_Salaries[Role];
            return 40.0; // default
        }
    }
}
