using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace oop_project2_Elitegrp.Classes
{
    internal static class File_Manager
    {
        private static string Customer_File = "Customers.txt";
        private static string Staff_File = "Staff.txt";

        
        //  CUSTOMER Save / Load / Update / Delete
        

        public static void Save_Customer(Customer Customer_Object)
        {
            try
            {
                string Customer_Data =
                    Customer_Object.Get_Customer_ID() + "|" +
                    Customer_Object.Get_Name() + "|" +
                    Customer_Object.Get_Last_Name() + "|" +
                    Customer_Object.Get_Email() + "|" +
                    Customer_Object.Get_Phone_Number() + "|" +
                    Customer_Object.Get_Address() + "|" +
                    Customer_Object.Get_Plan() + "|" +
                    Customer_Object.Get_Balance() + "|" +
                    Customer_Object.Get_Savings() + "|" +
                    Customer_Object.Get_Account_Number() + "|" +
                    Customer_Object.Get_Photo_Path();

                File.AppendAllText(Customer_File, Customer_Data + Environment.NewLine);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving customer: " + ex.Message);
            }
        }

        public static List<Customer> Load_Customers()
        {
            List<Customer> Customer_List = new List<Customer>();
            try
            {
                if (!File.Exists(Customer_File)) return Customer_List;

                string[] Lines = File.ReadAllLines(Customer_File);
                foreach (string Line in Lines)
                {
                    if (string.IsNullOrWhiteSpace(Line)) continue;
                    string[] Parts = Line.Split('|');
                    if (Parts.Length < 11) continue;

                    Customer New_Customer = new Customer();
                    New_Customer.Set_Customer_ID(Parts[0]);
                    New_Customer.Set_Name(Parts[1]);
                    New_Customer.Set_Last_Name(Parts[2]);
                    New_Customer.Set_Email(Parts[3]);
                    New_Customer.Set_Phone_Number(Parts[4]);
                    New_Customer.Set_Address(Parts[5]);
                    New_Customer.Set_Plan(Parts[6]);
                    New_Customer.Set_Balance(double.Parse(Parts[7]));
                    New_Customer.Set_Savings(double.Parse(Parts[8]));
                    New_Customer.Set_Account_Number(Parts[9]);
                    New_Customer.Set_Photo_Path(Parts[10]);
                    Customer_List.Add(New_Customer);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading customers: " + ex.Message);
            }
            return Customer_List;
        }

        public static void Update_All_Customers(List<Customer> Customer_List)
        {
            try
            {
                List<string> Lines = new List<string>();
                foreach (Customer Customer_Object in Customer_List)
                {
                    string Customer_Data =
                        Customer_Object.Get_Customer_ID() + "|" +
                        Customer_Object.Get_Name() + "|" +
                        Customer_Object.Get_Last_Name() + "|" +
                        Customer_Object.Get_Email() + "|" +
                        Customer_Object.Get_Phone_Number() + "|" +
                        Customer_Object.Get_Address() + "|" +
                        Customer_Object.Get_Plan() + "|" +
                        Customer_Object.Get_Balance() + "|" +
                        Customer_Object.Get_Savings() + "|" +
                        Customer_Object.Get_Account_Number() + "|" +
                        Customer_Object.Get_Photo_Path();
                    Lines.Add(Customer_Data);
                }
                File.WriteAllLines(Customer_File, Lines);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating customers: " + ex.Message);
            }
        }

    
        //  STAFF Save / Load / Update
        

        public static void Save_Staff(Staff Staff_Object)
        {
            try
            {
                string Staff_Data =
                    Staff_Object.Get_Staff_ID() + "|" +
                    Staff_Object.Get_Name() + "|" +
                    Staff_Object.Get_Last_Name() + "|" +
                    Staff_Object.Get_Email() + "|" +
                    Staff_Object.Get_Phone_Number() + "|" +
                    Staff_Object.Get_Address() + "|" +
                    Staff_Object.Get_Role() + "|" +
                    Staff_Object.Get_Staff_Balance() + "|" +
                    Staff_Object.Get_Normal_Hours() + "|" +
                    Staff_Object.Get_Extra_Hours() + "|" +
                    Staff_Object.Get_Salary_Per_Hour() + "|" +
                    Staff_Object.Get_Photo_Path();

                File.AppendAllText(Staff_File, Staff_Data + Environment.NewLine);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving staff: " + ex.Message);
            }
        }

        public static List<Staff> Load_Staff()
        {
            List<Staff> Staff_List = new List<Staff>();
            try
            {
                if (!File.Exists(Staff_File)) return Staff_List;

                string[] Lines = File.ReadAllLines(Staff_File);
                foreach (string Line in Lines)
                {
                    if (string.IsNullOrWhiteSpace(Line)) continue;
                    string[] Parts = Line.Split('|');
                    if (Parts.Length < 12) continue;

                    Staff New_Staff = new Staff();
                    New_Staff.Set_Staff_ID(Parts[0]);
                    New_Staff.Set_Name(Parts[1]);
                    New_Staff.Set_Last_Name(Parts[2]);
                    New_Staff.Set_Email(Parts[3]);
                    New_Staff.Set_Phone_Number(Parts[4]);
                    New_Staff.Set_Address(Parts[5]);
                    New_Staff.Set_Role(Parts[6]);
                    New_Staff.Set_Staff_Balance(double.Parse(Parts[7]));
                    New_Staff.Set_Normal_Hours(int.Parse(Parts[8]));
                    New_Staff.Set_Extra_Hours(int.Parse(Parts[9]));
                    New_Staff.Set_Salary_Per_Hour(double.Parse(Parts[10]));
                    New_Staff.Set_Photo_Path(Parts[11]);
                    Staff_List.Add(New_Staff);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading staff: " + ex.Message);
            }
            return Staff_List;
        }

        public static void Update_All_Staff(List<Staff> Staff_List)
        {
            try
            {
                List<string> Lines = new List<string>();
                foreach (Staff Staff_Object in Staff_List)
                {
                    string Staff_Data =
                        Staff_Object.Get_Staff_ID() + "|" +
                        Staff_Object.Get_Name() + "|" +
                        Staff_Object.Get_Last_Name() + "|" +
                        Staff_Object.Get_Email() + "|" +
                        Staff_Object.Get_Phone_Number() + "|" +
                        Staff_Object.Get_Address() + "|" +
                        Staff_Object.Get_Role() + "|" +
                        Staff_Object.Get_Staff_Balance() + "|" +
                        Staff_Object.Get_Normal_Hours() + "|" +
                        Staff_Object.Get_Extra_Hours() + "|" +
                        Staff_Object.Get_Salary_Per_Hour() + "|" +
                        Staff_Object.Get_Photo_Path();
                    Lines.Add(Staff_Data);
                }
                File.WriteAllLines(Staff_File, Lines);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating staff: " + ex.Message);
            }
        }
    }
}
