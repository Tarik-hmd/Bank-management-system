using System;

namespace oop_project2_Elitegrp.Classes
{
    public class Staff : Person
    {
        private string Staff_ID;
        private string Role;
        private double Staff_Balance;
        private int Normal_Hours;
        private int Extra_Hours;
        private double Salary_Per_Hour;

        public string Get_Staff_ID() { return Staff_ID; }
        public void Set_Staff_ID(string value) { Staff_ID = value; }

        public string Get_Role() { return Role; }
        public void Set_Role(string value) { Role = value; }

        public double Get_Staff_Balance() { return Staff_Balance; }
        public void Set_Staff_Balance(double value) { Staff_Balance = value; }

        public int Get_Normal_Hours() { return Normal_Hours; }
        public void Set_Normal_Hours(int value) { Normal_Hours = value; }

        public int Get_Extra_Hours() { return Extra_Hours; }
        public void Set_Extra_Hours(int value) { Extra_Hours = value; }

        public double Get_Salary_Per_Hour() { return Salary_Per_Hour; }
        public void Set_Salary_Per_Hour(double value) { Salary_Per_Hour = value; }

       
        public double Calculate_Unpaid_Salary()
        {
            double Normal_Pay = Normal_Hours * Salary_Per_Hour;
            double Extra_Pay = Extra_Hours * (Salary_Per_Hour * 1.4);
            return Normal_Pay + Extra_Pay;
        }
    }
}
