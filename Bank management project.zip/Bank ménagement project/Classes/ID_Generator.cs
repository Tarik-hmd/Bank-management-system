using System;
using System.Collections.Generic;

namespace oop_project2_Elitegrp.Classes
{
    internal static class ID_Generator
    {
        private static Random Random_Object = new Random();

        public static string Generate_Customer_ID(List<Customer> Existing_Customers)
        {
            string Letters = "ABCDE";
            string New_ID;
            do
            {
                char Random_Letter = Letters[Random_Object.Next(Letters.Length)];
                int Number = Random_Object.Next(1000, 9999);
                New_ID = Random_Letter + "-" + Number;
            }
            while (Existing_Customers.Exists(c => c.Get_Customer_ID() == New_ID));
            return New_ID;
        }

        public static string Generate_Staff_ID(List<Staff> Existing_Staff)
        {
            string Letters = "TLXYZ";
            string New_ID;
            do
            {
                char Random_Letter = Letters[Random_Object.Next(Letters.Length)];
                int Number = Random_Object.Next(1000, 9999);
                New_ID = Random_Letter + "-" + Number;
            }
            while (Existing_Staff.Exists(s => s.Get_Staff_ID() == New_ID));
            return New_ID;
        }

        public static string Generate_Account_Number(List<Customer> Existing_Customers)
        {
            string New_Account;
            do
            {
                New_Account = "5585 "
                    + Random_Object.Next(1000, 9999) + " "
                    + Random_Object.Next(1000, 9999) + " "
                    + Random_Object.Next(1000, 9999);
            }
            while (Existing_Customers.Exists(c => c.Get_Account_Number() == New_Account));
            return New_Account;
        }
    }
}
