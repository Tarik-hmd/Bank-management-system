using System;
using System.Collections.Generic;

namespace oop_project2_Elitegrp.Classes
{
    
    internal static class Sample_Data
    {
        public static void Seed_If_Empty()
        {
            List<Customer> Customer_List = File_Manager.Load_Customers();
            List<Staff> Staff_List = File_Manager.Load_Staff();

            if (Customer_List.Count == 0)
            {
                Seed_Customers(Customer_List);
            }

            if (Staff_List.Count == 0)
            {
                Seed_Staff(Staff_List);
            }
        }

        private static void Seed_Customers(List<Customer> Customer_List)
        {
            string[][] Customer_Data = new string[][]
            {
                new string[] { "Mahdi",   "Vahedian",  "msd.vahedian@gmail.com",  "78965412", "al. Ken 98, n.25, Warszawa",  "Silver Saving", "4000", "1500" },
                new string[] { "Anna",    "Kowalski",  "anna.k@gmail.com",        "500123456","ul. Nowy Swiat 5, Warszawa",   "Gold Saving",   "8500", "3200" },
                new string[] { "Piotr",   "Nowak",     "piotr.nowak@wp.pl",       "601234567","ul. Marszalkowska 12, Krakow","Basic",         "1200", "200"  },
                new string[] { "Sara",    "Zielinska", "sara.z@outlook.com",      "602345678","ul. Lipowa 3, Gdansk",         "Silver Saving", "3000", "800"  },
                new string[] { "Jakub",   "Wisniewski","jakub.w@gmail.com",       "603456789","ul. Dluga 7, Poznan",          "Gold Saving",   "9200", "4100" },
                new string[] { "Natalia", "Wojcik",    "natalia.w@yahoo.com",     "604567890","ul. Kwiatowa 15, Wroclaw",     "Basic",         "600",  "0"    }
            };

            foreach (string[] Row in Customer_Data)
            {
                Customer New_Customer = new Customer();
                New_Customer.Set_Customer_ID(ID_Generator.Generate_Customer_ID(Customer_List));
                New_Customer.Set_Account_Number(ID_Generator.Generate_Account_Number(Customer_List));
                New_Customer.Set_Name(Row[0]);
                New_Customer.Set_Last_Name(Row[1]);
                New_Customer.Set_Email(Row[2]);
                New_Customer.Set_Phone_Number(Row[3]);
                New_Customer.Set_Address(Row[4]);
                New_Customer.Set_Plan(Row[5]);
                New_Customer.Set_Balance(double.Parse(Row[6]));
                New_Customer.Set_Savings(double.Parse(Row[7]));
                New_Customer.Set_Photo_Path("");
                Customer_List.Add(New_Customer);
                File_Manager.Save_Customer(New_Customer);
            }
        }

        private static void Seed_Staff(List<Staff> Staff_List)
        {
            string[][] Staff_Data = new string[][]
            {
                new string[] { "Jenifer",  "Handson",  "handson.j@yahoo.com", "71124785", "Plac Wilsona 80, Warszawa", "General Manager"  },
                new string[] { "Robert",   "Kubiak",   "r.kubiak@bank.pl",    "505111222","ul. Sienkiewicza 4, Warsaw","Company CTO"      },
                new string[] { "Monika",   "Jasinska",  "m.jasinska@bank.pl", "506333444","ul. Wilanowska 9, Warsaw",  "Senior Accountant"},
                new string[] { "Tomasz",   "Lewandowski","t.lew@bank.pl",     "507555666","ul. Puławska 22, Warsaw",   "Teller"           }
            };

            foreach (string[] Row in Staff_Data)
            {
                Staff New_Staff = new Staff();
                New_Staff.Set_Staff_ID(ID_Generator.Generate_Staff_ID(Staff_List));
                New_Staff.Set_Name(Row[0]);
                New_Staff.Set_Last_Name(Row[1]);
                New_Staff.Set_Email(Row[2]);
                New_Staff.Set_Phone_Number(Row[3]);
                New_Staff.Set_Address(Row[4]);
                New_Staff.Set_Role(Row[5]);
                New_Staff.Set_Salary_Per_Hour(Salary_Calculator.Get_Salary_For_Role(Row[5]));
                New_Staff.Set_Staff_Balance(0);
                New_Staff.Set_Normal_Hours(0);
                New_Staff.Set_Extra_Hours(0);
                New_Staff.Set_Photo_Path("");
                Staff_List.Add(New_Staff);
                File_Manager.Save_Staff(New_Staff);
            }
        }
    }
}
