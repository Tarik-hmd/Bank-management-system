using System;

namespace oop_project2_Elitegrp.Classes
{
    public class Person
    {
        private string Name;
        private string Last_Name;
        private string Address;
        private string Email;
        private string Phone_Number;
        private string Photo_Path;

        public string Get_Name() { return Name; }
        public void Set_Name(string value) { Name = value; }

        public string Get_Last_Name() { return Last_Name; }
        public void Set_Last_Name(string value) { Last_Name = value; }

        public string Get_Address() { return Address; }
        public void Set_Address(string value) { Address = value; }

        public string Get_Email() { return Email; }
        public void Set_Email(string value) { Email = value; }

        public string Get_Phone_Number() { return Phone_Number; }
        public void Set_Phone_Number(string value) { Phone_Number = value; }

        public string Get_Photo_Path() { return Photo_Path; }
        public void Set_Photo_Path(string value) { Photo_Path = value; }
    }
}
